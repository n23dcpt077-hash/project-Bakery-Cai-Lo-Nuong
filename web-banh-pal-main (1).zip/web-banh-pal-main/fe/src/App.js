import { useLocation } from "react-router-dom";
import DefaultLayout from "./components/Layout/DefaultLayout";
import AppRoutes from "./routes";
import { FloatButton } from "antd";
import { FacebookFilled } from "@ant-design/icons";
function App() {
  const location = useLocation();

  const isAdminPage = location.pathname.startsWith("/admin");

  return (
    <div className="App">
      {isAdminPage ? (
        <div className="admin-layout">
          <AppRoutes />
        </div>
      ) : (
        <DefaultLayout>
          <AppRoutes />
          <FloatButton
            icon={<FacebookFilled style={{ color: "#fff", fontSize: 20 }} />}
            style={{
              right: 30,
              bottom: 30,
              width: 60,
              height: 60,
              backgroundColor: "#1877F2",
            }}
            tooltip="Chat Facebook"
            href="https://www.facebook.com/link-fanpage-cua-ban"
            target="_blank"
          />
        </DefaultLayout>
      )}
    </div>
  );
}

export default App;
