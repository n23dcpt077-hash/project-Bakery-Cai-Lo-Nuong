import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { ArrowLeftOutlined } from '@ant-design/icons';

import { 
  DetailWrapper, 
  DetailContainer, 
  DetailTitle, 
  DetailImage, 
  DetailMeta, 
  DetailContent,
  BackButton
} from './style';

const NewsDetail = () => {
  const { id } = useParams();
  const [newsItem, setNewsItem] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNewsDetail = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/news/${id}`);
        setNewsItem(res.data);
        setLoading(false);
      } catch (error) {
        console.error('Lỗi khi tải bài viết:', error);
        setLoading(false);
      }
    };

    if (id) fetchNewsDetail();
  }, [id]);

  if (loading) return <div style={{textAlign: 'center', padding: '50px'}}>Đang tải nội dung...</div>;
  if (!newsItem) return <div style={{textAlign: 'center', padding: '50px'}}>Không tìm thấy bài viết!</div>;

  return (
    <DetailWrapper>
      <DetailContainer>
        <Link to="/news" style={{ textDecoration: 'none' }}>
          <BackButton>
            <ArrowLeftOutlined /> Quay lại tin tức
          </BackButton>
        </Link>

        <DetailTitle>{newsItem.title}</DetailTitle>
        
        <DetailMeta>
          Đăng ngày: {new Date(newsItem.createdAt).toLocaleDateString('vi-VN')}
        </DetailMeta>

        {newsItem.image && (
          <DetailImage src={newsItem.image} alt={newsItem.title} />
        )}

        <DetailContent>
            {newsItem.content}
        </DetailContent>


      </DetailContainer>
    </DetailWrapper>
  );
};

export default NewsDetail;