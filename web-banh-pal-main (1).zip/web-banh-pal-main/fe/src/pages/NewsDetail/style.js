import styled from 'styled-components';

// ... (Giữ nguyên các style cũ của NewsPage) ...

// --- Style cho trang chi tiết (NewsDetail) ---

export const DetailWrapper = styled.div`
  background-color: #f9f9f9;
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  justify-content: center;
`;

export const DetailContainer = styled.div`
  max-width: 800px; // Giới hạn chiều rộng để dễ đọc giống báo điện tử
  width: 100%;
  background: #fff;
  padding: 40px;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);

  @media (max-width: 768px) {
    padding: 20px;
  }
`;

export const BackButton = styled.div`
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 20px;
  color: #666;
  font-weight: 500;
  cursor: pointer;
  transition: color 0.3s;

  &:hover {
    color: #007bff;
  }
`;

export const DetailTitle = styled.h1`
  font-size: 32px;
  font-weight: 700;
  color: #333;
  margin-bottom: 10px;
  line-height: 1.4;

  @media (max-width: 768px) {
    font-size: 24px;
  }
`;

export const DetailMeta = styled.p`
  font-size: 14px;
  color: #888;
  margin-bottom: 30px;
  border-bottom: 1px solid #eee;
  padding-bottom: 20px;
`;

export const DetailImage = styled.img`
  width: 100%;
  height: auto;
  border-radius: 8px;
  margin-bottom: 30px;
  object-fit: cover;
`;

export const DetailContent = styled.div`
  font-size: 18px;
  line-height: 1.8; // Khoảng cách dòng thoáng
  color: #444;
  text-align: justify;
  white-space: pre-line; // Giữ các dấu xuống dòng từ Admin nhập vào

  // Nếu nội dung có ảnh con bên trong
  img {
    max-width: 100%;
    height: auto;
    margin: 20px 0;
    border-radius: 4px;
  }
  
  p {
    margin-bottom: 20px;
  }
`;