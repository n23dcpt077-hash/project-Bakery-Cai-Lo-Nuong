import styled from 'styled-components';

export const NewsWrapper = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 40px 20px;
`;

export const SectionHeader = styled.h2`
  font-size: 28px;
  color: #333;
  text-align: center;
  margin-bottom: 40px;
  text-transform: uppercase;
`;

export const NewsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(3, 1fr); /* Chia 3 cột đều nhau */
  gap: 30px;

  @media (max-width: 992px) {
    grid-template-columns: repeat(2, 1fr); /* 2 cột trên tablet */
  }

  @media (max-width: 576px) {
    grid-template-columns: 1fr; /* 1 cột trên mobile */
  }
`;

export const NewsCard = styled.div`
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  transition: transform 0.3s ease;
  display: flex;       /* Quan trọng để căn đều chiều cao */
  flex-direction: column; 
  height: 100%;        /* Chiều cao full ô grid */

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.1);
  }
`;

export const CardImage = styled.div`
  height: 200px; /* Chiều cao cố định cho ảnh */
  width: 100%;
  overflow: hidden;
  
  img {
    width: 100%;
    height: 100%;
    object-fit: cover; /* Đảm bảo ảnh không bị méo */
    transition: transform 0.5s;
  }

  ${NewsCard}:hover & img {
    transform: scale(1.1);
  }
`;

export const CardBody = styled.div`
  padding: 20px;
  display: flex;
  flex-direction: column;
  flex-grow: 1; /* Đẩy phần này chiếm hết khoảng trống còn lại */
`;

export const NewsTitle = styled.h3`
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 10px;
  color: #333;
  display: -webkit-box;
  -webkit-line-clamp: 2; /* Giới hạn 2 dòng */
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

export const NewsDesc = styled.p`
  font-size: 14px;
  color: #666;
  line-height: 1.6;
  margin-bottom: 20px;
  flex-grow: 1; /* Đẩy nút read more xuống đáy */
  
  display: -webkit-box;
  -webkit-line-clamp: 3; /* Giới hạn 3 dòng mô tả */
  -webkit-box-orient: vertical;
  overflow: hidden;
`;

export const ReadMoreBtn = styled.span`
  font-size: 14px;
  color: #d0021b; /* Màu đỏ chủ đạo */
  font-weight: 600;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  
  &:hover {
    text-decoration: underline;
  }

  svg {
    margin-left: 5px;
  }
`;