import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { ReadOutlined } from '@ant-design/icons';

import { 
  NewsWrapper, NewsGrid, NewsCard, CardImage, 
  CardBody, NewsTitle, NewsDesc, ReadMoreBtn, SectionHeader 
} from './style';

const NewsPage = () => {
  const [newsList, setNewsList] = useState([]);

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/news');
        setNewsList(res.data);
      } catch (error) {
        console.error('Lỗi tải tin tức');
      }
    };
    fetchNews();
  }, []);

  return (
    <NewsWrapper>
      <SectionHeader>Tin Tức & Sự Kiện</SectionHeader>
      
      <NewsGrid>
        {newsList.map((item) => (
          <Link to={`/news/${item._id}`} style={{textDecoration: 'none'}}>
          <NewsCard key={item._id}>
            <CardImage>
              <img src={item.image} alt={item.title} />
            </CardImage>
            <CardBody>
              <NewsTitle>{item.title}</NewsTitle>
              <NewsDesc>{item.description}</NewsDesc>
              
                <ReadMoreBtn>
                  Đọc thêm <ReadOutlined />
                </ReadMoreBtn>
              
            </CardBody>
          </NewsCard>
          </Link>
        ))}
      </NewsGrid>
    </NewsWrapper>
  );
};

export default NewsPage;