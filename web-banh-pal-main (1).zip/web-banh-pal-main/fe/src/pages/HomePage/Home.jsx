import React from 'react';
import ProductSlider from '../../components/ProductSlider';
import FavoriteSlider from '../../components/FavoriteSlider';

const Home = () => {
  return (<div>
    <img src="https://cailonuong.com/wp-content/uploads/2025/11/COVER-WEB-2-1536x480.png" alt="banner"
    style={{ width: '100%', height: 'auto' }} />
  
    <ProductSlider />
    <FavoriteSlider />
  </div>);
};

export default Home;