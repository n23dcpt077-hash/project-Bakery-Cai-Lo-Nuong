import styled from 'styled-components';

export const PageContainer = styled.div`
  max-width: 1200px;
  margin: 40px auto;
  padding: 0 20px;
  /* Bỏ display flex cũ vì không còn sidebar nữa */
`;


export const ProductGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr); /* 4 cột như yêu cầu */
  gap: 20px;
  margin-top: 20px;

  /* Responsive */
  @media (max-width: 1024px) { grid-template-columns: repeat(3, 1fr); }
  @media (max-width: 768px) { grid-template-columns: repeat(2, 1fr); }
  @media (max-width: 480px) { grid-template-columns: 1fr; }
`;

export const LoadMoreBtn = styled.button`
  display: block;
  margin: 40px auto; /* Canh giữa */
  padding: 12px 40px;
  background-color: #fff;
  color: #002c1b;
  border: 1px solid #002c1b;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
  text-transform: uppercase;

  &:hover {
    background-color: #002c1b;
    color: #fff;
  }
`;

export const CategoryTitle = styled.h2`
  color: #002c1b;
  text-transform: uppercase;
  margin-bottom: 30px;
  text-align: center;
  font-size: 28px;
  
  &::after {
    content: '';
    display: block;
    width: 60px;
    height: 3px;
    background-color: #cfa144;
    margin: 10px auto 0;
  }
`;