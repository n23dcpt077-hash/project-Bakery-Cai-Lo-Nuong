import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link, useParams } from 'react-router-dom';
import { Card, ProductImage, ProductInfo } from '../../components/ProductSlider/style';
import { PageContainer, ProductGrid, LoadMoreBtn, CategoryTitle } from './style';

const MenuPage = () => {
  const { category } = useParams();
  
  const [menus, setMenus] = useState([]);
  const [filteredMenus, setFilteredMenus] = useState([]);
  const [visibleCount, setVisibleCount] = useState(20);

  const categoryNames = {
    'sweetbox': 'Sweetbox',
    'sweetin': 'Sweetin – Bánh hộp thiếc',
    'mousse': 'Bánh Mousse',
    'entremet': 'Bánh Entremet',
    'kem-bap': 'Bánh Kem Bắp',
    'flan-gato': 'Bánh Flan Gato',
    'healthy': 'Bánh Healthy',
    'banh-mi': 'Bánh nướng – Bánh mì'
  };

  useEffect(() => {
    const fetchMenus = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/menus');
        setMenus(res.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchMenus();
  }, []);

  useEffect(() => {
    if (category) {
      const filtered = menus.filter(item => item.category === category);
      setFilteredMenus(filtered);
    } else {
      setFilteredMenus(menus);
    }
    
    setVisibleCount(20); 
  }, [category, menus]);

  const handleLoadMore = () => {
    setVisibleCount(prev => prev + 20);
  };

  const currentDisplay = filteredMenus.slice(0, visibleCount);

  return (
    <PageContainer>
      <CategoryTitle>
        {category ? categoryNames[category] : 'Thực đơn bánh'}
      </CategoryTitle>

      {currentDisplay.length > 0 ? (
        <>
          <ProductGrid>
            {currentDisplay.map((product) => (
              <Card key={product._id}>
                <Link to={`/product/${product._id}`} style={{textDecoration:'none', display:'block'}}>
                  <ProductImage>
                    <img src={product.image} alt={product.name} />
                  </ProductImage>
                </Link>
                <ProductInfo>
                  <h3>
                    <Link to={`/product/${product._id}`} style={{color:'inherit', textDecoration:'none'}}>
                      {product.name}
                    </Link>
                  </h3>
                  <p>{product.price?.toLocaleString()} ₫</p>
                </ProductInfo>
              </Card>
            ))}
          </ProductGrid>

          {filteredMenus.length > visibleCount && (
            <LoadMoreBtn onClick={handleLoadMore}>
              Xem thêm
            </LoadMoreBtn>
          )}
        </>
      ) : (
        <p style={{ textAlign: 'center', margin: 50, color: '#666' }}>
          Chưa có sản phẩm nào trong danh mục này.
        </p>
      )}
    </PageContainer>
  );
};

export default MenuPage;