import React from 'react';
import styled from 'styled-components';

const PrivacyPolicy = () => {
  return (
    <PageContainer>
      <ContentWrapper>
        <MainTitle>CHÍNH SÁCH BẢO VỆ THÔNG TIN CÁ NHÂN NGƯỜI TIÊU DÙNG</MainTitle>
        
        <Section>
          <SectionTitle>1. Mục đích thu thập</SectionTitle>
          <Text>Chúng tôi thu thập thông tin cá nhân chỉ cần thiết nhằm phục vụ cho các mục đích:</Text>
          <StyledList>
            <ListItem><strong>Đơn Hàng:</strong> để xử lý các vấn đề liên quan đến đơn đặt hàng của khách hàng.</ListItem>
            <ListItem><strong>Duy Trì Tài Khoản:</strong> để tạo và duy trì tài khoản của khách hàng với chúng tôi, bao gồm cả các Chương trình Khách hàng Thân thiết hoặc các chương trình khác đi kèm.</ListItem>
            <ListItem><strong>Dịch Vụ Chăm Sóc Khách Hàng:</strong> bao gồm các phản hồi cho các yêu cầu, khiếu nại và phản hồi của khách hàng.</ListItem>
            <ListItem>
              <strong>Cá Nhân Hóa:</strong> Chúng tôi có thể tổ hợp dữ liệu được thu thập để có cái nhìn hoàn chỉnh hơn về người tiêu dùng, từ đó phục vụ tốt hơn:
              <SubList>
                <li>Để cải thiện và cá nhân hóa trải nghiệm của khách hàng.</li>
                <li>Để cải thiện các sản phẩm, dịch vụ, điều chỉnh phù hợp với nhu cầu và phát triển ý tưởng mới.</li>
                <li>Để phục vụ khách hàng với những giới thiệu, quảng cáo phù hợp với sự quan tâm của khách hàng.</li>
              </SubList>
            </ListItem>
            <ListItem><strong>An Ninh:</strong> ngăn ngừa các hoạt động phá hủy tài khoản hoặc giả mạo khách hàng.</ListItem>
            <ListItem><strong>Theo yêu cầu của pháp luật:</strong> tùy quy định vào từng thời điểm, chúng tôi có thể thu thập, lưu trữ và cung cấp theo yêu cầu của cơ quan nhà nước có thẩm quyền.</ListItem>
          </StyledList>
        </Section>

        <Section>
          <SectionTitle>2. Phạm vi thu thập</SectionTitle>
          <Text>Chúng tôi thu thập thông tin khách hàng khi:</Text>
          
          <SubSectionTitle>Khách hàng giao dịch trực tiếp với chúng tôi</SubSectionTitle>
          <Text>
            Thông tin cá nhân cung cấp chủ yếu trên website <Link href="https://cailonuong.com/">https://cailonuong.com/</Link>. 
            Thông tin bao gồm: Họ tên, ngày sinh, địa chỉ, số điện thoại, email, chi tiết thanh toán.
            Chi tiết đơn đặt hàng được lưu giữ nhưng vì lý do bảo mật nên chúng tôi không công khai trực tiếp.
          </Text>

          <SubSectionTitle>Khách hàng tương tác với chúng tôi</SubSectionTitle>
          <Text>
            Chúng tôi sử dụng cookies và công nghệ dấu khác để thu thập thông tin khi bạn tương tác với trang mua sắm.
            Cookie giúp ghi nhớ tên truy cập, giỏ hàng mà không cần nhập lại thông tin. Bạn có thể tắt cookie trên trình duyệt nhưng sẽ hạn chế quyền sử dụng.
            Cam kết cookie không bao gồm chi tiết cá nhân riêng tư và an toàn với virus.
          </Text>

          <SubSectionTitle>Các nguồn hợp pháp khác</SubSectionTitle>
          <Text>Chúng tôi có thể thu thập thông tin của bạn trên các nguồn hợp pháp khác.</Text>
        </Section>

        <Section>
          <SectionTitle>3. Thời gian lưu trữ</SectionTitle>
          <Text>
            Thông tin khách hàng được lưu trữ cho đến khi nhận được yêu cầu huỷ bỏ của khách hàng, hoặc khách hàng tự đăng nhập để huỷ bỏ. 
            Mọi thông tin của khách hàng đều được lưu trữ trên máy chủ của <Link href="https://cailonuong.com/">https://cailonuong.com/</Link>.
          </Text>
        </Section>

        <Section>
          <SectionTitle>4. Thông tin Khách hàng đối với bên thứ ba</SectionTitle>
          <Text>Chúng tôi cam kết không cung cấp thông tin khách hàng với bất kì bên thứ ba nào, trừ những trường hợp sau:</Text>
          <StyledList>
            <ListItem>Các đối tác cung cấp dịch vụ liên quan đến thực hiện đơn hàng (giới hạn trong phạm vi cần thiết và bảo mật).</ListItem>
            <ListItem>Nhà cung cấp dịch vụ bên thứ ba để thực hiện hoạt động website (yêu cầu tuân thủ luật bảo vệ thông tin).</ListItem>
            <ListItem>Các chương trình có tính liên kết, đồng thực hiện, thuê ngoài cho các mục đích nêu tại Mục 1.</ListItem>
            <ListItem>Yêu cầu pháp lý: Khi luật pháp yêu cầu hoặc cần thiết để tuân thủ quy trình pháp lý.</ListItem>
            <ListItem>Chuyển giao kinh doanh (nếu có): Trong trường hợp sáp nhập/hợp nhất, người mua sẽ có quyền truy cập thông tin.</ListItem>
          </StyledList>
        </Section>

        <Section>
          <SectionTitle>5. An toàn dữ liệu</SectionTitle>
          <Text>Chúng tôi thực hiện nhiều biện pháp an toàn:</Text>
          <StyledList>
            <ListItem><strong>Bảo đảm an toàn trong môi trường vận hành:</strong> Chỉ nhân viên, đại diện và nhà cung cấp dịch vụ có thẩm quyền mới được truy cập.</ListItem>
            <ListItem>Trong trường hợp máy chủ bị hacker tấn công, chúng tôi sẽ thông báo cho cơ quan chức năng và khách hàng.</ListItem>
            <ListItem>Các thông tin thanh toán được bảo mật theo tiêu chuẩn ngành.</ListItem>
          </StyledList>
        </Section>

        <Section>
          <SectionTitle>6. Quyền lợi của khách hàng</SectionTitle>
          <StyledList>
            <ListItem>Khách hàng có quyền cung cấp thông tin cá nhân và có thể thay đổi quyết định đó vào bất cứ lúc nào.</ListItem>
            <ListItem>Khách hàng có quyền tự kiểm tra, cập nhật, điều chỉnh thông tin cá nhân bằng cách đăng nhập vào tài khoản hoặc yêu cầu chúng tôi thực hiện.</ListItem>
          </StyledList>
        </Section>

        <Section>
          <SectionTitle>7. Yêu cầu xóa bỏ thông tin cá nhân</SectionTitle>
          <StyledList>
            <ListItem>Khách hàng có quyền yêu cầu xóa bỏ hoàn toàn các thông tin cá nhân lưu trữ trên hệ thống bất cứ khi nào.</ListItem>
            <ListItem>Gửi thư điện tử về <Link href="mailto:contact@cailonuong.com">contact@cailonuong.com</Link> để yêu cầu xóa bỏ.</ListItem>
          </StyledList>
        </Section>

        <Section>
          <SectionTitle>8. Thông tin liên hệ</SectionTitle>
          <Text>Nếu bạn có câu hỏi về Chính Sách này, vui lòng liên hệ:</Text>
          <ContactBox>
            <p>📞 Hotline: <Link href="tel:02888883388">028.8888.3388</Link></p>
            <p>📧 Email: <Link href="mailto:contact@cailonuong.com">contact@cailonuong.com</Link></p>
          </ContactBox>
        </Section>

      </ContentWrapper>
    </PageContainer>
  );
};

// --- Styled Components ---

const PageContainer = styled.div`
  background-color: #f5f5f5;
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  justify-content: center;
  font-family: 'Roboto', sans-serif; // Hoặc font chữ bạn đang dùng
`;

const ContentWrapper = styled.div`
  background-color: #ffffff;
  max-width: 900px;
  width: 100%;
  padding: 50px;
  border-radius: 10px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);

  @media (max-width: 768px) {
    padding: 20px;
  }
`;

const MainTitle = styled.h1`
  font-size: 28px;
  color: #2c3e50;
  text-align: center;
  margin-bottom: 40px;
  text-transform: uppercase;
  font-weight: 700;
  border-bottom: 2px solid #eee;
  padding-bottom: 20px;

  @media (max-width: 768px) {
    font-size: 22px;
  }
`;

const Section = styled.div`
  margin-bottom: 30px;
`;

const SectionTitle = styled.h2`
  font-size: 20px;
  color: #333;
  margin-bottom: 15px;
  font-weight: 600;
  border-left: 4px solid #007bff; // Điểm nhấn đầu dòng
  padding-left: 10px;
`;

const SubSectionTitle = styled.h3`
  font-size: 17px;
  color: #444;
  margin-top: 15px;
  margin-bottom: 8px;
  font-weight: 600;
  font-style: italic;
`;

const Text = styled.p`
  font-size: 16px;
  color: #555;
  line-height: 1.6;
  margin-bottom: 10px;
  text-align: justify;
`;

const StyledList = styled.ul`
  list-style-type: none; // Tắt dấu chấm tròn mặc định để dùng icon hoặc style riêng
  padding-left: 0;
`;

const ListItem = styled.li`
  font-size: 16px;
  color: #555;
  line-height: 1.6;
  margin-bottom: 10px;
  position: relative;
  padding-left: 20px;

  &::before {
    content: "•";
    color: #007bff;
    font-weight: bold;
    position: absolute;
    left: 0;
  }

  strong {
    color: #333;
    font-weight: 600;
  }
`;

const SubList = styled.ul`
  list-style-type: circle;
  margin-top: 5px;
  padding-left: 20px;
  
  li {
    margin-bottom: 5px;
    font-style: italic;
  }
`;

const Link = styled.a`
  color: #007bff;
  text-decoration: none;
  font-weight: 500;
  
  &:hover {
    text-decoration: underline;
    color: #0056b3;
  }
`;

const ContactBox = styled.div`
  background-color: #f9f9f9;
  padding: 15px;
  border-radius: 8px;
  border: 1px dashed #ccc;
  margin-top: 10px;

  p {
    margin: 5px 0;
    font-weight: 500;
    color: #333;
  }
`;

export default PrivacyPolicy;