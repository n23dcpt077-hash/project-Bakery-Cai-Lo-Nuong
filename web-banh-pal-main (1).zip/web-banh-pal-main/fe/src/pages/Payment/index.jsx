import React, { useState } from 'react';
import { Form, Input, Button, Radio, Row, Col, message } from 'antd';
import axios from 'axios'; 
import { useNavigate, useLocation } from 'react-router-dom';

import { 
  PageWrapper, SectionTitle, OrderSummaryBox, 
  PriceRow, PaymentBox, BankInfoBox 
} from './style';

const SHIP_FEE = 15000;
const INITIAL_CART = [
  { id: 1, name: 'Flan Gato Fruit & Pins - 20cm', price: 515000, quantity: 1 }
];

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
};

const PaymentPage = () => {
  const [form] = Form.useForm();
  const navigate = useNavigate();
  const location = useLocation();
  const [paymentMethod, setPaymentMethod] = useState('cod');
  
  const cartItems = location.state?.cartItems || INITIAL_CART;
  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const total = subtotal + SHIP_FEE;

  const onFinish = async (values) => {
    const newOrderPayload = {
      id: Math.floor(10000 + Math.random() * 90000).toString(),
      customer: {
        name: values.fullName,
        phone: values.phone,
        email: values.email,
        address: `${values.address}, ${values.district}, ${values.city}`,
        note: values.note
      },
      products: cartItems,
      amounts: { subtotal, ship: SHIP_FEE, total },
      paymentMethod: values.paymentMethod,
      date: new Date()
    };

    try {
      const res = await axios.post('http://localhost:5000/api/orders', newOrderPayload);
      message.success('Đặt hàng thành công!');
      form.resetFields();
      setTimeout(() => {
        navigate('/postpay', { state: { order: res.data } });
      }, 1000);
    } catch (error) {
      console.error(error);
      message.error('Lỗi khi gửi đơn hàng, vui lòng thử lại!');
    }
  };

  const vietnameseNameRegex = /^[a-zA-ZÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀỀỂưăạảấầẩẫậắằẳẵặẹẻẽềềểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵýỷỹ\s]+$/;

  return (
    <PageWrapper>
      <Form form={form} layout="vertical" onFinish={onFinish} initialValues={{ paymentMethod: 'cod' }}>
        <Row gutter={40}>
          <Col xs={24} md={14}>
            <SectionTitle>Thông tin thanh toán</SectionTitle>
            
            <Form.Item
              label="Họ và tên"
              name="fullName"
              rules={[
                { required: true, message: 'Vui lòng nhập họ tên!' },
                { pattern: vietnameseNameRegex, message: 'Họ tên phải đúng định dạng' }
              ]}
            >
              <Input placeholder="Nguyễn Văn A" size="large" />
            </Form.Item>

            <Form.Item
              label="Số điện thoại"
              name="phone"
              rules={[
                { required: true, message: 'Vui lòng nhập số điện thoại!' },
                { pattern: /^[0-9]{10}$/, message: 'Số điện thoại phải gồm 10 số' }
              ]}
            >
              <Input placeholder="034xxxx" size="large" />
            </Form.Item>

            <Form.Item
              label="Email"
              name="email"
              rules={[
                { required: true, message: 'Vui lòng nhập email!' },
                { type: 'email', message: 'Email không hợp lệ!' }
              ]}
            >
              <Input placeholder="email@example.com" size="large" />
            </Form.Item>

            <Form.Item label="Tỉnh/Thành phố" name="city" rules={[{ required: true, message: 'Chọn Tỉnh/Thành phố!' }]}>
              <Input placeholder="Tp. Hồ Chí Minh" size="large" />
            </Form.Item>

            <Form.Item label="Quận huyện" name="district" rules={[{ required: true, message: 'Chọn Quận huyện!' }]}>
              <Input placeholder="Quận 12" size="large" />
            </Form.Item>

            <Form.Item label="Địa chỉ" name="address" rules={[{ required: true, message: 'Nhập địa chỉ cụ thể!' }]}>
              <Input placeholder="Số nhà, tên đường..." size="large" />
            </Form.Item>

            <Form.Item label="Ghi chú đơn hàng (tuỳ chọn)" name="note">
              <Input.TextArea rows={4} placeholder="Ghi chú..." />
            </Form.Item>
          </Col>

          <Col xs={24} md={10}>
            <SectionTitle>Đơn hàng của bạn</SectionTitle>
            <OrderSummaryBox>
              <PriceRow style={{ fontWeight: 600, borderBottom: '1px solid #eee', paddingBottom: 10 }}>
                <span>Sản phẩm</span>
                <span>Tạm tính</span>
              </PriceRow>
              
              {cartItems.map(item => (
                <PriceRow key={item.id} style={{ fontSize: 14, color: '#555' }}>
                  <span>{item.name} <strong>× {item.quantity}</strong></span>
                  <span>{formatCurrency(item.price * item.quantity)}</span>
                </PriceRow>
              ))}

              <PriceRow>
                <span>Tạm tính</span>
                <span>{formatCurrency(subtotal)}</span>
              </PriceRow>
              <PriceRow>
                <span>Giao hàng</span>
                <span>{formatCurrency(SHIP_FEE)}</span>
              </PriceRow>

              <PriceRow className="total">
                <span>Tổng</span>
                <span>{formatCurrency(total)}</span>
              </PriceRow>

              <PaymentBox>
                <Form.Item name="paymentMethod" noStyle>
                  <Radio.Group onChange={e => setPaymentMethod(e.target.value)} style={{ width: '100%' }}>
                    <div style={{ marginBottom: 10 }}>
                        <Radio value="cod">Thanh toán tiền mặt khi nhận hàng</Radio>
                    </div>
                    <div>
                        <Radio value="banking">Chuyển khoản ngân hàng</Radio>
                    </div>
                  </Radio.Group>
                </Form.Item>

                {paymentMethod === 'banking' && (
                  <BankInfoBox>
                    <p><strong>Ngân hàng:</strong> VIB</p>
                    <p><strong>Chủ tài khoản:</strong> Cong ty TNHH Cai Lo Nuong</p>
                    <p><strong>Số tài khoản:</strong> 003863231</p>
                    <p>Nội dung: Tên + SĐT</p>
                  </BankInfoBox>
                )}
              </PaymentBox>

              <Button type="primary" htmlType="submit" size="large" danger block style={{ marginTop: 20, height: 50, fontWeight: 'bold' }}>
                ĐẶT HÀNG
              </Button>
            </OrderSummaryBox>
          </Col>
        </Row>
      </Form>
    </PageWrapper>
  );
};

export default PaymentPage;
