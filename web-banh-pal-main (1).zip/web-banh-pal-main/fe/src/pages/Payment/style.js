import styled from 'styled-components';

export const PageWrapper = styled.div`
  padding: 40px 20px;
  max-width: 1200px;
  margin: 0 auto;
  background-color: #f9f9f9;
  min-height: 100vh;
`;

export const SectionTitle = styled.h3`
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 20px;
  color: #333;
  text-transform: uppercase;
`;

export const OrderSummaryBox = styled.div`
  background: white;
  padding: 20px;
  border: 2px solid #dcdcdc;
  border-radius: 5px;
`;

export const PriceRow = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 15px;
  font-size: 15px;
  
  &.total {
    font-size: 20px;
    font-weight: bold;
    color: #d0021b;
    border-top: 1px solid #eee;
    padding-top: 15px;
  }
`;

export const PaymentBox = styled.div`
  margin-top: 20px;
  background: #fdfdfd;
  border: 1px solid #eee;
  padding: 15px;
  border-radius: 4px;
`;

export const BankInfoBox = styled.div`
  background-color: #f7f7f7;
  padding: 15px;
  margin-top: 10px;
  font-size: 13px;
  color: #666;
  border-left: 3px solid #d0021b;
`;