import styled from 'styled-components';
export const CartContainer = styled.div`
  max-width: 1200px;
  margin: 40px auto;
  padding: 0 20px;
`;

export const SuccessMessage = styled.div`
  background-color: #f6ffed;
  border: 1px solid #b7eb8f;
  padding: 15px;
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: #389e0d;
  font-size: 14px;
  
  a {
    color: #389e0d;
    font-weight: bold;
    text-decoration: none;
    &:hover { text-decoration: underline; }
  }
`;

export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 30px;

  th {
    text-align: left;
    padding: 15px;
    border-bottom: 2px solid #eee;
    color: #666;
    text-transform: uppercase;
    font-size: 12px;
  }
  td {
    padding: 20px 15px;
    border-bottom: 1px solid #eee;
    vertical-align: middle;
  }
`;

export const ProductCell = styled.div`
  display: flex;
  align-items: center;
  gap: 15px;
  img {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 4px;
  }
  h4 { margin: 0; font-size: 14px; color: #333; }
`;

export const RemoveBtn = styled.button`
  background: none;
  border: none;
  color: #999;
  cursor: pointer;
  font-size: 18px;
  &:hover { color: red; }
`;

export const CartSummary = styled.div`
  background-color: #f9f9f9;
  padding: 30px;
  border-radius: 4px;
  width: 350px;
  margin-left: auto; /* Đẩy sang phải */

  h3 { margin-top: 0; border-bottom: 1px solid #ddd; padding-bottom: 15px; }
  
  .row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 15px;
    font-size: 14px;
  }
  .total {
    font-size: 20px;
    font-weight: bold;
    color: #d32f2f;
  }
`;

export const CheckoutBtn = styled.button`
  background-color: #d68b00; /* Màu cam đậm */
  color: white;
  width: 100%;
  padding: 15px;
  border: none;
  font-weight: bold;
  text-transform: uppercase;
  cursor: pointer;
  margin-top: 10px;
  &:hover { background-color: #b57600; }
`;