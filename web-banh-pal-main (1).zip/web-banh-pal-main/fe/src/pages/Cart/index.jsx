import React from 'react';
import { useLocation, Link, useNavigate } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { CartContainer, SuccessMessage, Table, ProductCell, RemoveBtn, CartSummary, CheckoutBtn } from './style';
import PageTitle from '../../components/PageTitle/Pagetitle';

const Cart = () => {
  const { cartItems, removeFromCart, updateQuantity, totalPrice } = useCart();
  const location = useLocation();
  const navigate = useNavigate();

  const addedProduct = location.state?.addedProduct;

  const handleCheckout = () => {
    navigate('/payment');
  };

  return (
    <CartContainer>
      <PageTitle title="Giỏ hàng" />

      {addedProduct && (
        <SuccessMessage>
          <span>✅ "{addedProduct}" đã được thêm vào giỏ hàng.</span>
          <Link to="/menu-banh">Tiếp tục xem sản phẩm →</Link>
        </SuccessMessage>
      )}

      {cartItems.length === 0 ? (
        <div style={{textAlign: 'center', margin: 50}}>
            <h3>Giỏ hàng đang trống</h3>
            <Link to="/">Quay lại trang chủ</Link>
        </div>
      ) : (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 30 }}>
            <div style={{ flex: 2 }}>
                <Table>
                    <thead>
                        <tr>
                            <th>Sản phẩm</th>
                            <th>Giá</th>
                            <th>Số lượng</th>
                            <th>Tạm tính</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        {cartItems.map((item) => (
                            <tr key={item._id}>
                                <td>
                                    <ProductCell>
                                        <img src={item.image} alt={item.name} />
                                        <h4>{item.name}</h4>
                                    </ProductCell>
                                </td>
                                <td>{item.price.toLocaleString()} ₫</td>
                                <td>
                                    <div style={{display: 'flex', border: '1px solid #ddd', width: 'fit-content'}}>
                                        <button style={{border:'none', width:30, cursor:'pointer'}} onClick={()=>updateQuantity(item._id, item.quantity - 1)}>-</button>
                                        <input style={{width:30, textAlign:'center', border:'none'}} value={item.quantity} readOnly />
                                        <button style={{border:'none', width:30, cursor:'pointer'}} onClick={()=>updateQuantity(item._id, item.quantity + 1)}>+</button>
                                    </div>
                                </td>
                                <td style={{color: '#d32f2f', fontWeight:'bold'}}>
                                    {(item.price * item.quantity).toLocaleString()} ₫
                                </td>
                                <td>
                                    <RemoveBtn onClick={() => removeFromCart(item._id)}>×</RemoveBtn>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
                
                <Link to="/" style={{display: 'inline-block', marginTop: 20, textDecoration: 'none', color: '#555', border: '1px solid #ddd', padding: '10px 20px'}}>
                    ← Quay lại trang chủ
                </Link>
            </div>

            <CartSummary>
                <h3>Cộng giỏ hàng</h3>
                <div className="row">
                    <span>Tạm tính</span>
                    <span>{totalPrice.toLocaleString()} ₫</span>
                </div>
                <div className="row">
                    <span>Giao hàng</span>
                    <span>Giao miễn phí</span>
                </div>
                <div className="row total">
                    <span>Tổng</span>
                    <span>{totalPrice.toLocaleString()} ₫</span>
                </div>
                
                <CheckoutBtn onClick={handleCheckout}>
                    Tiến hành thanh toán
                </CheckoutBtn>
            </CartSummary>
        </div>
      )}
    </CartContainer>
  );
};

export default Cart;