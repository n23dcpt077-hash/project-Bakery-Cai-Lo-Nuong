import React, { useEffect, useState } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { Button } from 'antd';
import { PageWrapper, SuccessMsg, OrderInfoList, SectionTitle, BankBox, OrderTable, AddressGrid } from './style';

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
};

const formatDate = (dateString) => {
  if (!dateString) return new Date().toLocaleDateString('vi-VN');
  return new Date(dateString).toLocaleDateString('vi-VN');
};

const PostPay = () => {
  const location = useLocation();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    if (location.state?.order) {
      setOrder(location.state.order);
    } 
    else {
      const orders = JSON.parse(localStorage.getItem('orders') || '[]');
      if (orders.length > 0) {
        setOrder(orders[0]); 
      }
    }
  }, [location.state]);

  if (!order) return <div style={{textAlign:'center', padding: 50}}>Đang tải dữ liệu... <Link to="/">Về trang chủ</Link></div>;

  return (
    <PageWrapper>
      <SuccessMsg>Cảm ơn bạn. Đơn hàng của bạn đã được nhận.</SuccessMsg>

      <OrderInfoList>
        <li>Mã đơn hàng: <strong>{order.orderCode || order.id || order._id}</strong></li>
        
        <li>Ngày: <strong>{formatDate(order.createdAt || order.date)}</strong></li>
        
        <li>Tổng cộng: <strong>{formatCurrency(order.amounts?.total || 0)}</strong></li>
        
        <li>Phương thức thanh toán: <strong>{order.paymentMethod === 'banking' ? 'Chuyển khoản ngân hàng' : 'Tiền mặt (COD)'}</strong></li>
      </OrderInfoList>

      {order.paymentMethod === 'banking' && (
        <>
          <p style={{marginBottom: 20}}>
            Chuyển khoản thanh toán đơn hàng theo thông tin bên dưới, vui lòng ghi <strong>“{order.customer?.phone}”</strong> của bạn trong nội dung thanh toán để chúng tôi xử lý đơn hàng nhanh hơn.
          </p>
          <SectionTitle>Thông tin chuyển khoản ngân hàng</SectionTitle>
          <BankBox>
            <h4>Công ty TNHH Cái Lò Nướng:</h4>
            <p>Ngân hàng: <strong>VIB - PGD Trần Nhân Tôn</strong></p>
            <p>Số tài khoản: <strong>003863231</strong></p>
          </BankBox>
        </>
      )}

      <SectionTitle>Chi tiết đơn hàng</SectionTitle>
      <OrderTable>
        <thead>
          <tr>
            <th>Sản phẩm</th>
            <th style={{textAlign: 'right'}}>Tổng</th>
          </tr>
        </thead>
        <tbody>
          {order.products?.map((item, index) => (
            <tr key={index}>
              <td className="product-name">
                {item.name} <span>× {item.quantity}</span>
              </td>
              <td className="amount">{formatCurrency(item.price * item.quantity)}</td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <td>Tổng số phụ:</td>
            <td className="amount">{formatCurrency(order.amounts?.subtotal || 0)}</td>
          </tr>
          <tr>
            <td>Giao nhận hàng:</td>
            <td className="amount">{formatCurrency(order.amounts?.ship || 0)}</td>
          </tr>
          <tr>
            <td>Phương thức thanh toán:</td>
            <td className="amount" style={{fontWeight: 'normal'}}>
                {order.paymentMethod === 'banking' ? 'Chuyển khoản ngân hàng' : 'Tiền mặt'}
            </td>
          </tr>
          <tr>
            <td><strong>Tổng cộng:</strong></td>
            <td className="amount">{formatCurrency(order.amounts?.total || 0)}</td>
          </tr>
        </tfoot>
      </OrderTable>

      <AddressGrid>
        <div>
          <SectionTitle style={{marginTop: 0}}>Địa chỉ thanh toán</SectionTitle>
          <address>
            {order.customer?.phone}<br/>
            <strong>{order.customer?.name}</strong><br/>
            {order.customer?.email}<br/>
            {order.customer?.address}
          </address>
        </div>
        
        <div>
          <SectionTitle style={{marginTop: 0}}>Địa chỉ giao hàng</SectionTitle>
          <address>
            {order.customer?.phone}<br/>
            <strong>{order.customer?.name}</strong><br/>
             {order.customer?.address}
          </address>
        </div>
      </AddressGrid>

      <div style={{textAlign: 'center', marginTop: 50}}>
        <Link to="/menu-banh">
             <Button type="primary" size="large" style={{background: '#d0021b', borderColor: '#d0021b'}}>Tiếp tục mua hàng</Button>
        </Link>
      </div>
    </PageWrapper>
  );
};

export default PostPay;