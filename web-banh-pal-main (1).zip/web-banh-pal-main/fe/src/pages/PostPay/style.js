import styled from 'styled-components';

export const PageWrapper = styled.div`
  max-width: 800px;
  margin: 40px auto;
  padding: 20px;
  background: #fff;
  font-family: 'Arial', sans-serif;
  color: #333;
`;

export const SuccessMsg = styled.p`
  font-size: 20px;
  color: #333;
  margin-bottom: 30px;
  text-align: center;
  font-weight: 500;
  
  &::before {
    content: '✓';
    display: block;
    font-size: 40px;
    color: #4caf50;
    margin-bottom: 10px;
  }
`;

export const OrderInfoList = styled.ul`
  list-style: none;
  padding: 0;
  display: flex;
  justify-content: space-between;
  margin-bottom: 40px;
  flex-wrap: wrap;
  gap: 15px;

  li {
    font-size: 13px;
    color: #777;
    text-transform: uppercase;
    
    strong {
      display: block;
      margin-top: 5px;
      color: #333;
      font-size: 15px;
      text-transform: none;
    }
  }
`;

export const SectionTitle = styled.h3`
  font-size: 18px;
  text-transform: uppercase;
  margin-bottom: 20px;
  margin-top: 40px;
  color: #333;
  font-weight: bold;
`;

export const BankBox = styled.div`
  background-color: #f7f7f7;
  padding: 25px;
  border-left: 5px solid #d0021b; /* Màu đỏ thương hiệu */
  margin-bottom: 30px;
  
  h4 {
    margin: 0 0 10px 0;
    font-size: 16px;
  }
  
  p {
    margin: 5px 0;
    font-size: 14px;
    color: #555;
  }
`;

export const OrderTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 30px;

  th, td {
    padding: 15px 0;
    text-align: left;
    border-bottom: 1px solid #eee;
  }

  th {
    text-transform: uppercase;
    font-size: 14px;
    color: #333;
    font-weight: bold;
  }

  td {
    font-size: 14px;
    color: #555;
    
    &.product-name {
      color: #d0021b; /* Màu tên sản phẩm */
      font-weight: 500;
      
      span {
        color: #333;
        font-weight: normal;
      }
    }
    
    &.amount {
      text-align: right;
      font-weight: bold;
      color: #333;
    }
  }
  
  tfoot tr:last-child td {
    border-bottom: none;
    font-size: 18px;
    color: #d0021b;
  }
`;

export const AddressGrid = styled.div`
  display: flex;
  gap: 40px;
  flex-wrap: wrap;

  div {
    flex: 1;
    min-width: 250px;
    
    h4 {
      font-size: 16px;
      margin-bottom: 15px;
      text-transform: uppercase;
    }

    address {
      font-style: normal;
      font-size: 14px;
      line-height: 1.6;
      color: #555;
      
      strong {
        color: #333;
      }
    }
  }
`;