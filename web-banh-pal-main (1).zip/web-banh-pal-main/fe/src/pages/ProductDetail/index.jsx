import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../../context/CartContext';
import { 
  DetailContainer, ContentWrapper, ProductTitle, ImageSection, 
  InfoSection, Description, ToggleButton, Actions, QuantityBox, AddToCartBtn 
} from './style';
import PageTitle from '../../components/PageTitle/Pagetitle';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { addToCart } = useCart();
  
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [isExpanded, setIsExpanded] = useState(false);
  const [loading, setLoading] = useState(true);

  const collectionType = location.state?.collection; 

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      try {
        if (collectionType) {
          const res = await axios.get(`http://localhost:5000/api/${collectionType}/${id}`);
          setProduct(res.data);
        } 
        else {
          try {
            const res = await axios.get(`http://localhost:5000/api/products/${id}`);
            setProduct(res.data);
          } catch (err1) {
            try {
              const res2 = await axios.get(`http://localhost:5000/api/favourites/${id}`);
              setProduct(res2.data);
            } catch (err2) {
              try {
                const res3 = await axios.get(`http://localhost:5000/api/menus/${id}`);
                setProduct(res3.data);
              } catch (err3) {
                console.error("Không tìm thấy bánh ở bất kỳ kho nào");
                setProduct(null);
              }
            }
          }
        }
      } catch (err) {
        console.error("Lỗi tải sản phẩm", err);
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id, collectionType]);

  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity);
      navigate('/cart', { state: { addedProduct: product.name } });
    }
  };

  if (loading) return <div style={{textAlign: 'center', padding: 50}}>Đang tải dữ liệu...</div>;
  if (!product) return <div style={{textAlign: 'center', padding: 50}}>Không tìm thấy sản phẩm này</div>;

  return (
    <DetailContainer>
      <PageTitle title={product.name} />
      <ProductTitle>{product.name}</ProductTitle>

      <ContentWrapper>
        <ImageSection>
          <img src={product.image} alt={product.name} />
        </ImageSection>

        <InfoSection>
          <div className="price">{product.price?.toLocaleString()} ₫</div>

          <Description className={!isExpanded ? 'clamped' : ''}>
            {product.description || "Chưa có mô tả chi tiết cho sản phẩm này."}
          </Description>
          
          {(product.description?.length > 200) && (
             <ToggleButton onClick={() => setIsExpanded(!isExpanded)}>
               {isExpanded ? 'Thu gọn' : 'Xem thêm'}
             </ToggleButton>
          )}

          <Actions>
            <QuantityBox>
              <button onClick={() => setQuantity(q => Math.max(1, q - 1))}>-</button>
              <input type="text" value={quantity} readOnly />
              <button onClick={() => setQuantity(q => q + 1)}>+</button>
            </QuantityBox>

            <AddToCartBtn onClick={handleAddToCart}>
              Thêm vào giỏ hàng
            </AddToCartBtn>
          </Actions>
        </InfoSection>
      </ContentWrapper>
    </DetailContainer>
  );
};

export default ProductDetail;