import styled from 'styled-components';

export const DetailContainer = styled.div`
  max-width: 1200px;
  margin: 40px auto;
  padding: 0 20px;
  /* BỎ display: flex ở đây đi, vì ta muốn xếp dọc (Title ở trên, nội dung ở dưới) */
`;

export const ProductTitle = styled.h1`
  font-size: 32px;
  color: #002c1b;
  margin-bottom: 20px; /* Cách ảnh một chút */
  text-transform: uppercase;
  font-weight: 700;
  border-bottom: 1px solid #eee; /* Thêm gạch chân mờ cho đẹp */
  padding-bottom: 15px;
`;

export const ContentWrapper = styled.div`
  display: flex;
  gap: 40px;

  @media (max-width: 768px) {
    flex-direction: column; /* Mobile thì xếp dọc */
  }
`;

export const ImageSection = styled.div`
  flex: 1; /* Chiếm 1 phần */
  img {
    width: 100%;
    height: 500px;
    object-fit: cover;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
  }
`;

export const InfoSection = styled.div`
  flex: 1; /* Chiếm 1 phần */
  
  /* Bỏ style h1 cũ ở đây đi vì đã đưa ra ngoài */

  .price {
    font-size: 28px; /* Tăng kích thước giá lên xíu cho nổi */
    color: #cfa144;
    font-weight: bold;
    margin-bottom: 20px;
  }
`;

export const Description = styled.div`
  font-size: 16px;
  line-height: 1.6;
  color: #555;
  margin-bottom: 30px;
  &.clamped {
    display: -webkit-box;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
`;

export const ToggleButton = styled.span`
  color: #002c1b;
  font-weight: bold;
  cursor: pointer;
  display: block;
  margin-bottom: 20px;
  &:hover { text-decoration: underline; }
`;

export const Actions = styled.div`
  display: flex;
  gap: 20px;
  align-items: center;
`;

export const QuantityBox = styled.div`
  display: flex;
  border: 1px solid #ddd;
  border-radius: 4px;
  button {
    background: #f9f9f9;
    border: none;
    width: 40px;
    height: 40px;
    font-size: 18px;
    cursor: pointer;
    &:hover { background: #eee; }
  }
  input {
    width: 50px;
    text-align: center;
    border: none;
    border-left: 1px solid #ddd;
    border-right: 1px solid #ddd;
    outline: none;
  }
`;

export const AddToCartBtn = styled.button`
  background-color: #cfa144;
  color: white;
  border: none;
  padding: 0 30px;
  height: 40px;
  font-weight: bold;
  text-transform: uppercase;
  border-radius: 4px;
  cursor: pointer;
  transition: 0.3s;
  &:hover { background-color: #b88b2e; }
`;