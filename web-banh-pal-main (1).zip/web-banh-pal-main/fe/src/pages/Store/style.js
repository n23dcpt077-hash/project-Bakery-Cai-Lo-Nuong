import styled from 'styled-components';

export const StoreContainer = styled.div`
  max-width: 1200px;
  margin: 40px auto;
  padding: 0 20px;
  min-height: 80vh;
`;



export const BranchCard = styled.div`
  display: flex;
  gap: 30px; /* Khoảng cách giữa cột chữ và cột map */
  margin-bottom: 60px; /* Khoảng cách giữa các chi nhánh */
  align-items: center; /* Căn giữa theo chiều dọc */
  border-bottom: 1px solid #eee; /* Đường kẻ mờ ngăn cách */
  padding-bottom: 40px;

  &:last-child {
    border-bottom: none;
  }

  /* Responsive: Mobile xếp dọc */
  @media (max-width: 768px) {
    flex-direction: column;
    text-align: center;
  }
`;

export const BranchInfo = styled.div`
  flex: 1; /* Chiếm 1 phần */
  
  h3 {
    font-size: 22px;
    color: #002c1b;
    margin-bottom: 15px;
    font-weight: 700;
  }

  p {
    font-size: 16px;
    color: #555;
    line-height: 1.6;
    margin-bottom: 10px;
  }
`;

export const MapFrame = styled.div`
  flex: 1.5; /* Map to hơn chữ xíu (chiếm 1.5 phần) */
  height: 350px;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 15px rgba(0,0,0,0.1); /* Đổ bóng nhẹ cho map nổi lên */

  iframe {
    width: 100%;
    height: 100%;
    border: 0;
  }
`;