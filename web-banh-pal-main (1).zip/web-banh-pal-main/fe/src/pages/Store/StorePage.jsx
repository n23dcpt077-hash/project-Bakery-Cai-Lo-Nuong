import React from 'react';
import PageTitle from '../../components/PageTitle/Pagetitle';
import { 
  StoreContainer, 
   
  BranchCard, 
  BranchInfo, 
  MapFrame 
} from './style';

const StorePage = () => {
  const mapIcon = "https://cdn-icons-png.flaticon.com/512/854/854878.png";

  const branches = [
    {
      id: 1,
      name: "Chi nhánh 1 - Quận 1",
      address: "173 Nguyễn Thái Học, Phường Phạm Ngũ Lão, Quận 1, TP. Hồ Chí Minh",
      mapSrc: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.616075427906!2d106.6917613748047!3d10.76404598938402!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752f16ad86379b%3A0x67397637841f375e!2zMTczIE5ndXnhu4VuIFRow6FpIEjhu41jLCBQaMaw4budbmcgUGjhuqFtIE5Zw7lmIEzDo28sIFF14bqtbiAxLCBI4buTIENow60gTWluaCwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1701934000000!5m2!1svi!2s"
    },
    {
      id: 2,
      name: "Chi nhánh 2 - Tân Bình",
      address: "2A Ba Gia, Phường 7, Quận Tân Bình, TP. Hồ Chí Minh",
      mapSrc: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.123456789012!2d106.654321098765!3d10.798765432109!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3175292929292929%3A0x123456789abcdef!2zMkEgQmEgR2lhLCBQaMaw4budbmcgNywgVMOibiBCw6xuaCwgSOG7kyBDaMOtIE1pbmgsIFZp4buZdCBOYW0!5e0!3m2!1svi!2s!4v1701934000000!5m2!1svi!2s" 
    },
    {
      id: 3,
      name: "Chi nhánh 3 - Thủ Đức",
      address: "29 Lê Văn Việt, Phường Hiệp Phú, TP. Thủ Đức, TP. Hồ Chí Minh",
      mapSrc: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3918.523456789012!2d106.789012345678!3d10.845678901234!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3175272727272727%3A0xabcdef123456789!2zMjkgTMOqIFbEg24gVmnhu4d0LCBIaeG7h3AgUGjDuiwgVGjhu6cgxJDhu6ljLCBI4buTIENow60gTWluaCwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1701934000000!5m2!1svi!2s"
    }
  ];

  return (
    <StoreContainer>
      <PageTitle title="Hệ thống cửa hàng" icon={mapIcon} />
      
  

      {branches.map((branch) => (
        <BranchCard key={branch.id}>
          <BranchInfo>
            <h3>{branch.name}:</h3>
            <p>{branch.address}</p>
            <p><strong>Giờ mở cửa:</strong> 8:00 - 22:00 (Tất cả các ngày)</p>
            <p><strong>Hotline:</strong> 028.8888.3388</p>
          </BranchInfo>

          <MapFrame>
            <iframe 
              src={branch.mapSrc}
              allowFullScreen="" 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title={`map-${branch.id}`}
            ></iframe>
          </MapFrame>
        </BranchCard>
      ))}

    </StoreContainer>
  );
};

export default StorePage;