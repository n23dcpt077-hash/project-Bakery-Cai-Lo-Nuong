import styled from 'styled-components';
import { Layout } from 'antd';

const { Content, Sider, Header } = Layout;
export const Container = styled.div`
  max-width: 1000px; /* Giới hạn chiều rộng cho dễ đọc */
  margin: 40px auto;
  padding: 0 20px;
  min-height: 80vh;
`;

export const BannerWrapper = styled.div`
  width: 100%;
  margin-bottom: 30px;
  text-align: center;
`;

export const BannerImage = styled.img`
  width: 50%;
  height: auto; /* Giới hạn chiều cao để không chiếm hết màn hình */
  object-fit: cover; /* Hoặc 'contain' tùy ảnh thật */
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0,0,0,0.05);
`;

export const IntroText = styled.p`
  font-size: 16px;
  line-height: 1.6;
  color: #333;
  margin-bottom: 40px;
  text-align: justify; /* Căn đều 2 bên cho đẹp */
`;

export const SectionTitle = styled.h3`
  font-size: 18px;
  font-weight: 700;
  color: #002c1b; /* Màu xanh đậm thương hiệu */
  text-transform: uppercase;
  margin-bottom: 20px;
  
  /* Tạo điểm nhấn nhỏ (tùy chọn) */
  border-left: 4px solid #cfa144;
  padding-left: 10px;
`;

export const PolicyList = styled.ul`
  margin-bottom: 30px;
  padding-left: 20px; /* Thụt đầu dòng */
  list-style-type: disc; /* Dấu chấm tròn */
`;

export const PolicyItem = styled.li`
  margin-bottom: 15px;
  line-height: 1.6;
  color: #555;
  font-size: 15px;

  /* Tô đậm những từ quan trọng */
  strong {
    color: #002c1b;
    font-weight: 700;
  }
`;

export const TierBox = styled.div`
  background-color: #fcfcfc;
  border: 1px solid #eee;
  border-left: 4px solid #cfa144; /* Viền vàng bên trái làm điểm nhấn */
  padding: 20px;
  margin-bottom: 20px;
  border-radius: 4px;

  &:hover {
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
  }
`;

export const TierTitle = styled.h4`
  font-size: 16px;
  color: #333;
  margin-bottom: 10px;
  font-weight: 600;

  span {
    color: #cfa144; /* Tô màu vàng cho tên cấp bậc (MEMBER, VIP SILVER...) */
    font-weight: 800;
  }
`;

export const SubList = styled.ul`
  padding-left: 20px;
  list-style-type: circle; /* Dấu tròn rỗng */
  color: #666;
  
  li {
    margin-bottom: 5px;
  }
`;


export const AdminLayout = styled(Layout)`
  min-height: 100vh;
`;

export const StyledSider = styled(Sider)`
  background: #001529;
  .logo {
    height: 32px;
    margin: 16px;
    background: rgba(255, 255, 255, 0.3);
    border-radius: 4px; /* Placeholder cho logo */
  }
`;

export const StyledHeader = styled(Header)`
  background: #fff;
  padding: 0 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
  z-index: 1;
`;

export const StyledContent = styled(Content)`
  margin: 24px 16px;
  padding: 24px;
  background: #fff;
  border-radius: 8px; /* Bo góc mềm mại hơn */
  min-height: 280px;
  overflow: initial;
`;

export const StatisticCard = styled.div`
  background: #fff;
  padding: 20px;
  border-radius: 8px;
  border: 1px solid #f0f0f0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  transition: all 0.3s;
  
  &:hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  }
`;

export const StatusTag = styled.span`
  font-weight: 600;
  text-transform: uppercase;
  font-size: 12px;
`;