import React from 'react';
import PageTitle from '../../components/PageTitle/Pagetitle'; 
import { 
  Container, 
  BannerWrapper, 
  BannerImage, 
  IntroText, 
  SectionTitle,
  PolicyList,
  PolicyItem,
  TierBox,
  TierTitle,
  SubList
} from './style';

const Loyalty = () => {
  const giftIcon = "https://cdn-icons-png.flaticon.com/512/3209/3209955.png"; 
  const bannerPlaceholder = "https://cailonuong.com/wp-content/uploads/2023/08/membership.jpg"; 

  return (
    <Container>
      <PageTitle title="Khách hàng thân thiết" icon={giftIcon}  />

      <BannerWrapper>
        <BannerImage src={bannerPlaceholder} alt="Chương trình khách hàng thân thiết" />
      </BannerWrapper>

      <IntroText>
        Tri ân quý khách hàng đã luôn tin tưởng lựa chọn Cái Lò Nướng cho những bữa tiệc ngọt ngào, chúng tôi xin gửi đến quý khách những ưu đãi hấp dẫn chỉ dành riêng cho khách hàng thân thiết của Cái Lò Nướng.
      </IntroText>

      <SectionTitle>A. KHÁCH HÀNG THÂN THIẾT</SectionTitle>
      <PolicyList>
        <PolicyItem><strong>Đối với khách hàng mua bánh tại cửa hàng:</strong> Nhân viên cửa hàng sẽ hỗ trợ đăng ký thông tin thành viên khi quý khách hoàn thành hoá đơn mua hàng đầu tiên.</PolicyItem>
        <PolicyItem><strong>Đối với khách hàng đặt hàng online:</strong> Khi quý khách đặt hàng lần đầu tiên tại page Cái Lò Nướng, hệ thống sẽ tự động tạo tài khoản khách hàng thành viên dựa trên số điện thoại đặt hàng.</PolicyItem>
      </PolicyList>

      <SectionTitle>B. CHÍNH SÁCH MEMBER/ VIP</SectionTitle>
      <IntroText style={{ marginBottom: 20 }}>
        Khách hàng thành viên khi mua sắm tại hệ thống cửa hàng Cái Lò Nướng hoặc Online Store được tham gia chương trình Tích lũy doanh số như sau:
      </IntroText>

      <TierBox>
        <TierTitle>1. Khách hàng có doanh số mua hàng tích lũy từ 800k sẽ trở thành <span>MEMBER</span></TierTitle>
        <SubList>
          <li>Ưu đãi:
            <ul style={{ paddingLeft: 20, marginTop: 5 }}>
              <li>Freeship đơn hàng nội thành 30k</li>
              <li>Ưu tiên tuần lễ sinh nhật khách hàng tặng voucher giảm 15%</li>
            </ul>
          </li>
        </SubList>
      </TierBox>

      <TierBox>
        <TierTitle>2. Khách hàng có doanh số mua hàng tích lũy từ 1,5 đến dưới 2,5 triệu sẽ trở thành <span>VIP SILVER</span></TierTitle>
        <SubList>
          <li>Ưu đãi:
            <ul style={{ paddingLeft: 20, marginTop: 5 }}>
               <li>Luôn giảm 10%</li>
               <li>Freeship đơn hàng nội thành 30k</li>
               <li>Ưu tiên tuần lễ sinh nhật khách hàng tặng voucher giảm 15%</li>
            </ul>
          </li>
        </SubList>
      </TierBox>

      <TierBox>
        <TierTitle>3. Khách hàng có doanh số mua hàng tích lũy từ 2,5 đến dưới 5 triệu sẽ trở thành <span>VIP GOLD</span></TierTitle>
        <SubList>
          <li>Ưu đãi:
            <ul style={{ paddingLeft: 20, marginTop: 5 }}>
               <li>Luôn giảm 10%</li>
               <li>Freeship đơn hàng nội thành 40k</li>
               <li>Ưu tiên tuần lễ sinh nhật khách hàng tặng voucher giảm 20%</li>
            </ul>
          </li>
        </SubList>
      </TierBox>


      <TierBox style={{ borderLeftColor: '#b9f2ff' }}>
        <TierTitle>4. Khách hàng có doanh số mua hàng tích luỹ từ 5 triệu sẽ trở thành <span style={{ color: '#00bcd4' }}>VIP DIAMOND</span></TierTitle>
        <SubList>
          <li>Ưu đãi:
            <ul style={{ paddingLeft: 20, marginTop: 5 }}>
               <li>Luôn giảm 15%</li>
               <li>Freeship mọi đơn hàng nội thành</li>
               <li>Ưu tiên tuần lễ sinh nhật khách hàng tặng voucher giảm 20%</li>
            </ul>
          </li>
        </SubList>
      </TierBox>

      <SectionTitle style={{ marginTop: 40 }}>QUY ĐỊNH CHUNG:</SectionTitle>
      <PolicyList>
        <PolicyItem>Chương trình khuyến mãi và gia hạn thành viên sẽ được cập nhật hàng năm.</PolicyItem>
        <PolicyItem>Ưu đãi giảm giá được áp dụng khi mua sản phẩm nguyên giá.</PolicyItem>
        <PolicyItem>Nếu có nhiều chương trình ưu đãi sẽ ưu tiên chương trình ưu đãi cao nhất.</PolicyItem>
        <PolicyItem>Khách hàng thành viên được ưu tiên nhận tin về chương trình khuyến mãi hoặc sản phẩm mới của Cái Lò Nướng.</PolicyItem>
        <PolicyItem>Khách hàng thành viên được tham gia các chương trình khuyến mãi dành riêng cho khách hàng VIP.</PolicyItem>
        <PolicyItem>Ưu đãi áp dụng tại cửa hàng và online store.</PolicyItem>
        <PolicyItem>Không áp dụng đồng thời các ưu đãi thanh toán qua ứng dụng Grab.</PolicyItem>
        <PolicyItem>Cái Lò Nướng có thể cập nhật, thay đổi các điều khoản về ưu đãi để phù hợp với nhu cầu khách hàng và tình hình vận hành thực tế.</PolicyItem>
        <PolicyItem>Ưu đãi giao hàng áp dụng cho hoá đơn từ 250.000 đồng trở lên.</PolicyItem>
      </PolicyList>

      <div style={{ 
        marginTop: 30, 
        paddingTop: 20, 
        borderTop: '1px solid #eee', 
        fontSize: '15px', 
        color: '#333',
        fontWeight: '500'
      }}>
        Mọi ý kiến đóng góp và thắc mắc xin liên hệ Cái Lò Nướng qua Hotline: <span style={{color: '#cfa144', fontWeight:'bold'}}>028.8888.3388</span> hoặc gửi email về địa chỉ: <span style={{color: '#cfa144', fontWeight:'bold'}}>cailonuong@gmail.com</span>.
      </div>

      <div style={{ height: 50 }}></div>
    </Container>
  );
};

export default Loyalty;