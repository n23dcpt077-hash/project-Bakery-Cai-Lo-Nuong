import React from 'react';
import { Link } from 'react-router-dom';
import PageTitle from '../../components/PageTitle/Pagetitle';
import { Container, Title, Content, Highlight, BottomLink } from './style';

const ShipPolicy = () => {
  const truckIcon = "https://cdn-icons-png.flaticon.com/512/709/709790.png";

  return (
    <Container>
      <PageTitle 
        title="Chính sách giao hàng" 
        icon={truckIcon}
      />

      <Title>
        Chính sách giao hàng của Cái Lò Nướng được cập nhật ngày <span>1/12/2020</span>
      </Title>

      <Content>
        <p>
          Chúng tôi xây dựng đội ngũ giao hàng riêng để đảm bảo cho khách hàng trải nghiệm mua hàng tốt nhất. Hiện nay, chúng tôi giao hàng đến các quận, huyện tại khu vực Thành Phố Hồ Chí Minh các ngày trong tuần.
        </p>

        <p>
          Khách hàng có thể biết phí giao hàng khi nhập địa chỉ nhận hàng tại form đặt hàng. Để được giải đáp thêm về phí giao hàng, khu vực giao hàng khách hàng liên hệ Hotline <Highlight>028.8888.3388</Highlight> để được hỗ trợ.
        </p>

        <p>
          Dựa vào thông tin đặt hàng, chúng tôi sẽ cố gắng giao hàng đến địa chỉ nhận hàng chênh lệch tối đa <Highlight>30 phút</Highlight> (hoặc có thể sớm hơn tùy tuyến đường và điều kiện giao thông, điều kiện thời tiết lúc giao hàng). Trong mọi trường hợp, nhân viên giao hàng sẽ liên hệ với khách hàng để xác nhận trước khi giao hàng.
        </p>

        <p>
          Khi nhận bánh, Khách hàng kiểm tra bánh đã đúng theo yêu cầu, phụ kiện kèm theo để chúng tôi xử lý sự cố (nếu có) một cách nhanh nhất. Trường hợp sự cố phát hiện sau khi nhân viên giao hàng đã rời đi, chúng tôi sẽ hỗ trợ một số trường hợp nhất định. Tuy nhiên thời gian hỗ trợ có thể sẽ mất thêm thời gian. Mong khách hàng thông cảm.
        </p>
      </Content>

      <BottomLink>
        Quý khách hàng xem thêm Chính sách trả tiền – hoàn tiền tại đây: <Link to="/policy/return">Chính sách trả hàng - hoàn tiền</Link>
      </BottomLink>

    </Container>
  );
};

export default ShipPolicy;