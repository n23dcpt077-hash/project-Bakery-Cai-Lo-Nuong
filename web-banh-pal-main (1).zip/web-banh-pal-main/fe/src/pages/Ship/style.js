import styled from 'styled-components';


export const Container = styled.div`
  max-width: 1000px; /* Giới hạn chiều rộng để dễ đọc giống trang báo */
  margin: 40px auto;
  padding: 0 20px;
  min-height: 60vh;
`;

export const Title = styled.h1`
  font-size: 24px;
  color: #002c1b; /* Màu xanh thương hiệu */
  font-weight: 700;
  margin-bottom: 30px;
  line-height: 1.4;
  
  span {
    color: #cfa144; /* Tô màu vàng cho ngày tháng */
  }
`;

export const Content = styled.div`
  font-size: 16px;
  line-height: 1.8; /* Khoảng cách dòng thoáng */
  color: #333;
  text-align: justify; /* Căn đều 2 bên */

  p {
    margin-bottom: 20px; /* Khoảng cách giữa các đoạn văn */
  }
`;

export const Highlight = styled.span`
  font-weight: bold;
  color: #002c1b;
`;

export const BottomLink = styled.div`
  margin-top: 40px;
  padding-top: 20px;
  border-top: 1px solid #eee;
  font-style: italic;
  color: #666;

  a {
    color: #cfa144;
    font-weight: bold;
    text-decoration: none;
    &:hover {
      text-decoration: underline;
    }
  }
`;