import React from 'react';
import styled from 'styled-components';

const ReturnPolicy = () => {
  return (
    <PageContainer>
      <ContentWrapper>
        <MainTitle>CHÍNH SÁCH ĐỔI TRẢ & HOÀN TIỀN</MainTitle>
        
        <IntroText>
          Chúng tôi cố gắng hỗ trợ quý khách hàng có được trải nghiệm mua hàng tốt nhất tại website 
          <strong> Cái Lò Nướng</strong> với các chính sách mua hàng & hoàn tiền như sau:
        </IntroText>

        <PolicyList>
          <PolicyItem>
            Bạn không phải nhận hàng & thanh toán nếu kiểm tra sản phẩm giao đến không đúng với hóa đơn bạn đặt, 
            hoặc bị hư hỏng khi vận chuyển.
          </PolicyItem>

          <PolicyItem>
            Chúng tôi sẽ không hoàn lại tiền nếu bánh đã giao đến bạn đúng theo yêu cầu nhưng bạn từ chối nhận, 
            hoặc hư hỏng xảy ra sau quá trình kiểm tra nhận hàng giữa bạn với nhân viên giao hàng của chúng tôi.
          </PolicyItem>

          <PolicyItem>
            Nếu bạn đã thanh toán trước mà có sự cố trong quá trình giao hàng hoặc sản phẩm bị lỗi, 
            chúng tôi sẽ hoàn trả lại <strong>100% giá trị đơn hàng</strong> trong vòng tối đa 7 ngày làm việc (có thể sớm hơn).
          </PolicyItem>

          <PolicyItem>
            Trong trường hợp bạn hủy đơn hàng khi đã đặt cọc, chúng tôi sẽ <strong>không hoàn trả lại tiền cọc</strong> nếu đã đến ngày giao hàng 
            như thỏa thuận hoặc bánh bạn đặt đã được chúng tôi làm (áp dụng với các size bánh lớn).
          </PolicyItem>

          <PolicyItem>
            Trong trường hợp bạn hủy đơn hàng khi đã thực hiện thanh toán (tiền mặt hoặc chuyển khoản), sau khi chúng tôi xác nhận 
            khoản thanh toán của bạn thành công, chúng tôi sẽ hoàn trả lại <strong>100% giá trị đã thanh toán</strong> trong vòng tối đa 7 ngày làm việc 
            (có thể sớm hơn).
          </PolicyItem>

          <PolicyItem>
            Trong trường hợp phải hoàn trả tiền hàng cho bạn và bạn đã thực hiện thanh toán qua chuyển khoản ngân hàng trước đó, 
            chúng tôi phải xác nhận đã nhận được khoản thanh toán thành công của bạn thì mới tiến hành phương thức hoàn trả tiền hàng theo thủ tục.
          </PolicyItem>

          <PolicyItem>
            Mọi yêu cầu về việc hoàn trả tiền hàng ngay lập tức sẽ không được chấp nhận, chúng tôi sẽ thực hiện quy trình kiểm tra 
            xác nhận thanh toán và chuyển hoàn tiền hàng trong vòng tối đa 7 ngày làm việc (có thể sớm hơn).
          </PolicyItem>

          <PolicyItem>
            Phương thức chuyển khoản sẽ áp dụng cho việc hoàn trả tiền hàng, bạn vui lòng cung cấp thông tin tài khoản ngân hàng 
            cho chúng tôi khi thông báo yêu cầu hoàn trả tiền hàng.
          </PolicyItem>
        </PolicyList>

        <ContactNote>
          Nếu có bất kỳ thắc mắc nào, vui lòng liên hệ Hotline: <a href="tel:02888883388">028.8888.3388</a> để được hỗ trợ nhanh nhất.
        </ContactNote>

      </ContentWrapper>
    </PageContainer>
  );
};

// --- Styled Components ---

const PageContainer = styled.div`
  background-color: #f5f5f5;
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  justify-content: center;
  font-family: 'Roboto', sans-serif;
`;

const ContentWrapper = styled.div`
  background-color: #ffffff;
  max-width: 900px;
  width: 100%;
  padding: 50px;
  border-radius: 8px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);

  @media (max-width: 768px) {
    padding: 25px;
  }
`;

const MainTitle = styled.h1`
  font-size: 26px;
  color: #d35400; // Màu cam đậm (hoặc màu thương hiệu của bạn) tạo cảm giác chú ý
  text-align: center;
  margin-bottom: 30px;
  text-transform: uppercase;
  font-weight: 700;
  border-bottom: 2px solid #eee;
  padding-bottom: 20px;
`;

const IntroText = styled.p`
  font-size: 16px;
  color: #555;
  line-height: 1.6;
  margin-bottom: 25px;
  text-align: justify;
  font-style: italic;

  strong {
    color: #333;
    font-weight: 600;
  }
`;

const PolicyList = styled.ol`
  padding-left: 20px;
  margin: 0;
  counter-reset: policy-counter; // Tạo bộ đếm số thứ tự tùy chỉnh
`;

const PolicyItem = styled.li`
  font-size: 16px;
  line-height: 1.6;
  color: #444;
  margin-bottom: 20px;
  position: relative;
  list-style: none; // Tắt số mặc định để dùng số custom đẹp hơn
  padding-left: 30px;
  text-align: justify;

  &::before {
    counter-increment: policy-counter;
    content: counter(policy-counter) ".";
    position: absolute;
    left: 0;
    top: 0;
    font-weight: bold;
    color: #d35400; // Màu số thứ tự đồng bộ với tiêu đề
    font-size: 16px;
  }

  strong {
    color: #000;
    font-weight: 600;
  }
`;

const ContactNote = styled.div`
  margin-top: 40px;
  padding: 15px;
  background-color: #fff8e1; // Nền vàng nhạt cảnh báo/lưu ý
  border-left: 4px solid #ffc107;
  border-radius: 4px;
  color: #664d03;
  font-size: 15px;
  
  a {
    color: #d35400;
    font-weight: bold;
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }
`;

export default ReturnPolicy;