import React from 'react';
import styled from 'styled-components';

const TermsPage = () => {
  return (
    <Container>
      <ContentWrapper>
        <IntroText>
          Xin vui lòng đọc các điều khoản sau cẩn thận trước khi sử tiến hành mua hàng & thực hiện thanh toán. 
          Với việc ra quyết định mua hàng tại website <LinkText href="https://cailonuong.com">https://cailonuong.com</LinkText>, 
          bạn đã đồng ý với các điều khoản sử dụng của chúng tôi. Các điều khoản này có thể thay đổi theo thời gian 
          và bạn sẽ phải tuân theo các điều khoản được hiển thị từ thời điểm bạn đọc được các điều khoản này. 
          Chúng tôi luôn luôn mong muốn đem đến cho khách hàng với chất lượng dịch vụ tốt nhất.
        </IntroText>

        <StyledList>
          <ListItem>
            <strong>Phương thức thanh toán:</strong> chúng tôi hỗ trợ việc đặt hàng online & thanh toán trực tiếp 
            với nhân viên giao hàng khi nhận hàng hoặc bạn có thể thanh toán trước đơn hàng thông qua chuyển khoản 
            Ngân hàng hoặc qua tài khoản Momo.
          </ListItem>
          
          <ListItem>
            <strong>Thời gian thanh toán:</strong> bạn có thể thanh toán trước khi đặt hàng hoặc ngay sau khi nhận hàng. 
            Chúng tôi không hỗ trợ công nợ đơn hàng.
          </ListItem>
          
          <ListItem>
            Khi bạn cung cấp thông tin mua hàng của bạn cho chúng tôi, chúng tôi được phép sử dụng thông tin đó để 
            hoàn tất quá trình giao hàng, giải quyết sự cố xảy ra nếu có sau quá trình mua hàng, và sử dụng để chăm sóc, 
            gửi đến bạn các thông tin khuyến mãi (có thể) có trong quá trình hoạt động bán hàng sau này.
          </ListItem>
        </StyledList>
      </ContentWrapper>
    </Container>
  );
};

// --- Styled Components Definition ---

const Container = styled.div`
  display: flex;
  justify-content: center;
  padding: 40px 20px;
  background-color: #f9f9f9; // Màu nền nhẹ cho toàn trang
  min-height: 100vh;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
`;

const ContentWrapper = styled.div`
  max-width: 900px; // Giới hạn chiều rộng giống trang web tiêu chuẩn
  background-color: #ffffff;
  padding: 40px;
  border-radius: 8px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05); // Đổ bóng nhẹ cho đẹp
  color: #555555; // Màu chữ xám đen dịu mắt
`;

const IntroText = styled.p`
  font-size: 16px;
  line-height: 1.6; // Khoảng cách dòng thoáng dễ đọc
  margin-bottom: 24px;
  text-align: justify; // Căn đều 2 bên cho văn bản đẹp hơn
  
  @media (max-width: 768px) {
    text-align: left; // Trên mobile nên để căn trái để tránh lỗi khoảng trắng
  }
`;

const LinkText = styled.a`
  color: #007bff; // Màu xanh link tiêu chuẩn
  text-decoration: none;
  font-weight: 500;
  
  &:hover {
    text-decoration: underline;
    color: #0056b3;
  }
`;

const StyledList = styled.ol`
  padding-left: 20px; // Thụt đầu dòng cho danh sách số
  margin: 0;
`;

const ListItem = styled.li`
  font-size: 16px;
  line-height: 1.6;
  margin-bottom: 16px; // Khoảng cách giữa các mục
  color: #555555;
  padding-left: 8px; // Khoảng cách giữa số thứ tự và nội dung

  &::marker {
    color: #333; // Màu số thứ tự đậm hơn chút
    font-weight: bold;
  }

  strong {
    color: #333; // In đậm các tiêu đề mục
    font-weight: 600;
  }
`;

export default TermsPage;