import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Table, Button, Modal, Form, Input, message, Image, Tabs, Space, Select,
  Layout, Menu, Card, Statistic, Tag, Popconfirm, Row, Col, Breadcrumb, Tooltip 
} from 'antd';
import { 
  DeleteOutlined, PlusOutlined, StarOutlined, FireOutlined, EditOutlined, 
  AppstoreOutlined, LogoutOutlined, PieChartOutlined, ShopOutlined,
  DollarCircleOutlined, ShoppingCartOutlined, CloseCircleOutlined, StopOutlined,
  CheckOutlined, EyeOutlined, FileTextOutlined
} from '@ant-design/icons';
import axios from 'axios';
import InvoiceModal from './InvoiceModal'; 

const { Header, Content, Sider } = Layout;

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
};

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [selectedKey, setSelectedKey] = useState('dashboard'); 
  const [form] = Form.useForm();
  const categoryOptions = [
    { value: 'sweetbox', label: 'Sweetbox' },
    { value: 'sweetin', label: 'Sweetin – Bánh hộp thiếc' },
    { value: 'mousse', label: 'Bánh Mousse' },
    { value: 'entremet', label: 'Bánh Entremet' },
    { value: 'kem-bap', label: 'Bánh Kem Bắp' },
    { value: 'flan-gato', label: 'Bánh Flan Gato' },
    { value: 'healthy', label: 'Bánh Healthy' },
    { value: 'banh-mi', label: 'Bánh nướng – Bánh mì' },
  ];
  const [newsData, setNewsData] = useState([]);
  const [editingNews, setEditingNews] = useState(null);
  const [isNewsModalOpen, setIsNewsModalOpen] = useState(false);

  const fetchNews = useCallback(async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/news');
      setNewsData(res.data);
    } catch (error) { console.error(error); }
  }, []);

  const handleSaveNews = async (values) => {
    try {
      if (editingNews) {
        await axios.put(`http://localhost:5000/api/news/${editingNews._id}`, values);
        message.success('Cập nhật tin thành công!');
      } else {
        await axios.post(`http://localhost:5000/api/news`, values);
        message.success('Thêm tin mới thành công!');
      }
      setIsNewsModalOpen(false);
      form.resetFields();
      setEditingNews(null);
      fetchNews();
    } catch (err) {
      message.error('Lỗi khi lưu tin tức');
    }
  };

  const handleDeleteNews = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/news/${id}`);
      message.success('Đã xóa tin tức');
      fetchNews();
    } catch (err) {
      message.error('Lỗi khi xóa');
    }
  };

  const newsColumns = [
    { title: 'Ảnh', dataIndex: 'image', key: 'image', render: src => <Image width={60} src={src} /> },
    { title: 'Tiêu đề', dataIndex: 'title', key: 'title', width: '30%' },
    { title: 'Mô tả ngắn', dataIndex: 'description', key: 'description', ellipsis: true },
    { title: 'Ngày tạo', dataIndex: 'createdAt', render: date => new Date(date).toLocaleDateString('vi-VN') },
    {
      title: 'Hành động', key: 'action',
      render: (_, record) => (
        <Space>
          <Button type="primary" icon={<EditOutlined />} onClick={() => { setEditingNews(record); form.setFieldsValue(record); setIsNewsModalOpen(true); }} />
          <Popconfirm title="Xóa tin này?" onConfirm={() => handleDeleteNews(record._id)}>
             <Button danger icon={<DeleteOutlined />} />
          </Popconfirm>
        </Space>
      )
    }
  ];

  const [orders, setOrders] = useState([]);
  const [loadingOrders, setLoadingOrders] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [isInvoiceOpen, setIsInvoiceOpen] = useState(false);

  const fetchOrders = useCallback(async () => {
    setLoadingOrders(true);
    try {
      const res = await axios.get('http://localhost:5000/api/orders'); 
      setOrders(res.data);
    } catch (error) {
      console.error(error);
      message.error('Không tải được danh sách đơn hàng!');
    } finally {
      setLoadingOrders(false);
    }
  }, []);

  const handleUpdateStatus = async (orderId, newStatus) => {
    try {
        await axios.put(`http://localhost:5000/api/orders/${orderId}`, { status: newStatus });
        message.success(newStatus === 'approved' ? 'Đã duyệt đơn!' : 'Đã hủy đơn!');
        fetchOrders();
    } catch (error) {
        message.error('Lỗi khi cập nhật trạng thái');
    }
  };

  const handleViewDetail = (order) => {
    setSelectedOrder(order);
    setIsInvoiceOpen(true);
  };

  const totalRevenue = orders
    .filter(o => o.status === 'approved')
    .reduce((sum, o) => sum + (o.amounts?.total || 0), 0);
  const pendingCount = orders.filter(o => o.status === 'pending').length;
  const cancelledCount = orders.filter(o => o.status === 'cancelled').length;

  const orderColumns = [
    { title: 'Mã ĐH', dataIndex: '_id', key: '_id', width: 100, render: text => <b>#{text.slice(-5)}</b> },
    { 
      title: 'Khách hàng', dataIndex: ['customer', 'name'], key: 'customerName',
      render: (text, record) => (
        <div>
          <div style={{fontWeight: 500}}>{text}</div>
          <div style={{ fontSize: 12, color: '#888' }}>{record.customer?.phone}</div>
        </div>
      )
    },
    { title: 'Tổng tiền', dataIndex: ['amounts', 'total'], render: val => <span style={{color: '#d0021b', fontWeight: 600}}>{formatCurrency(val)}</span> },
    { title: 'Ngày đặt', dataIndex: 'createdAt', render: date => new Date(date).toLocaleDateString('vi-VN') },
    { 
      title: 'Trạng thái', dataIndex: 'status', 
      render: (status) => {
        let color = status === 'approved' ? 'success' : status === 'cancelled' ? 'error' : 'warning';
        let text = status === 'approved' ? 'ĐÃ DUYỆT' : status === 'cancelled' ? 'ĐÃ HỦY' : 'CHỜ DUYỆT';
        return <Tag color={color}>{text}</Tag>;
      }
    },
    {
      title: 'Hành động', key: 'action',
      render: (_, record) => (
        <Space>
           <Tooltip title="Xem chi tiết & In">
              <Button icon={<EyeOutlined />} onClick={() => handleViewDetail(record)} />
           </Tooltip>
           {record.status === 'pending' && (
             <>
                <Tooltip title="Duyệt đơn">
                    <Button type="primary" size="small" icon={<CheckOutlined />} onClick={() => handleUpdateStatus(record._id, 'approved')} />
                </Tooltip>
                <Popconfirm title="Hủy đơn này?" onConfirm={() => handleUpdateStatus(record._id, 'cancelled')}>
                    <Button type="primary" danger size="small" icon={<StopOutlined />} />
                </Popconfirm>
             </>
           )}
        </Space>
      ),
    },
  ];

  const [productData, setProductData] = useState([]);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [collectionType, setCollectionType] = useState('products');
  const [editingProduct, setEditingProduct] = useState(null);

  const fetchProducts = useCallback(async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/${collectionType}`);
      setProductData(res.data);
    } catch (error) { console.error(error); }
  }, [collectionType]);

  const handleSaveProduct = async (values) => {
    try {
        if (editingProduct) {
             await axios.put(`http://localhost:5000/api/${collectionType}/${editingProduct._id}`, values);
             message.success('Cập nhật thành công!');
        } else {
             await axios.post(`http://localhost:5000/api/${collectionType}`, values);
             message.success('Thêm mới thành công!');
        }
        setIsProductModalOpen(false);
        form.resetFields();
        setEditingProduct(null);
        fetchProducts();
    } catch (error) { message.error('Lỗi lưu sản phẩm'); }
  };

  const handleDeleteProduct = async (id) => { await axios.delete(`http://localhost:5000/api/${collectionType}/${id}`); fetchProducts(); };
  
  const openAddProductModal = () => { setEditingProduct(null); form.resetFields(); setIsProductModalOpen(true); };
  const openEditProductModal = (record) => { setEditingProduct(record); form.setFieldsValue(record); setIsProductModalOpen(true); };

  const productColumns = [
    { title: 'Ảnh', dataIndex: 'image', key: 'image', render: (img) => <Image width={50} src={img} /> },
    { title: 'Tên bánh', dataIndex: 'name', key: 'name' },
    { title: 'Giá', dataIndex: 'price', key: 'price', render: (price) => formatCurrency(price) },
    {
      title: 'Hành động', key: 'action',
      render: (_, record) => (
        <Space>
          <Button type="primary" icon={<EditOutlined />} onClick={() => openEditProductModal(record)} />
          <Popconfirm title="Xóa?" onConfirm={() => handleDeleteProduct(record._id)}><Button danger icon={<DeleteOutlined />} /></Popconfirm>
        </Space>
      )
    },
  ];

  useEffect(() => {
    if (selectedKey === 'dashboard') fetchOrders();
    if (selectedKey === 'products') fetchProducts();
    if (selectedKey === 'news') fetchNews();
  }, [selectedKey, fetchOrders, fetchProducts, fetchNews]);

  const handleLogout = () => { localStorage.removeItem('token'); navigate('/login'); message.success('Đã đăng xuất'); };

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider collapsible collapsed={collapsed} onCollapse={(value) => setCollapsed(value)}>
        <div style={{ height: 32, margin: 16, background: 'rgba(255, 255, 255, 0.2)', borderRadius: 6, display: 'flex', justifyContent: 'center', alignItems: 'center', color: '#fadb14', fontWeight: 'bold' }}>ADMIN</div>
        <Menu 
          theme="dark" defaultSelectedKeys={['dashboard']} mode="inline"
          onClick={(e) => setSelectedKey(e.key)}
          items={[
            { key: 'dashboard', icon: <PieChartOutlined />, label: 'Tổng quan đơn hàng' },
            { key: 'products', icon: <ShopOutlined />, label: 'Quản lý sản phẩm' },
            { key: 'news', icon: <FileTextOutlined />, label: 'Quản lý tin tức' },
          ]}
        />
      </Sider>

      <Layout className="site-layout">
        <Header style={{ padding: '0 20px', background: '#fff', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
           <h2 style={{ margin: 0 }}>HỆ THỐNG QUẢN TRỊ</h2>
           <Button type="text" danger icon={<LogoutOutlined />} onClick={handleLogout}>Đăng xuất</Button>
        </Header>

        <Content style={{ margin: '16px' }}>
          {selectedKey === 'dashboard' && (
            <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
              <Breadcrumb style={{ margin: '0 0 16px 0' }} items={[{ title: 'Admin' }, { title: 'Tổng quan' }]} />
              
              <Row gutter={16} style={{ marginBottom: 24 }}>
                <Col span={8}><Card><Statistic title="Doanh thu thực tế" value={totalRevenue} precision={0} valueStyle={{ color: '#3f8600' }} prefix={<DollarCircleOutlined />} suffix="₫" /></Card></Col>
                <Col span={8}><Card><Statistic title="Đơn chờ duyệt" value={pendingCount} valueStyle={{ color: '#faad14' }} prefix={<ShoppingCartOutlined />} /></Card></Col>
                <Col span={8}><Card><Statistic title="Đơn đã hủy" value={cancelledCount} valueStyle={{ color: '#cf1322' }} prefix={<CloseCircleOutlined />} /></Card></Col>
              </Row>

              <Tabs defaultActiveKey="recent">
                  <Tabs.TabPane tab="Danh sách đơn hàng gần đây" key="recent">
                      <Table dataSource={orders.filter(o => o.status === 'pending')} columns={orderColumns} rowKey="_id" loading={loadingOrders} />
                  </Tabs.TabPane>
                  <Tabs.TabPane tab="Lịch sử giao dịch (Đã xử lý)" key="history">
                      <Table dataSource={orders.filter(o => o.status !== 'pending')} columns={orderColumns} rowKey="_id" loading={loadingOrders} />
                  </Tabs.TabPane>
              </Tabs>
            </div>
          )}

          {selectedKey === 'products' && (
            <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
               <Breadcrumb style={{ margin: '0 0 16px 0' }} items={[{ title: 'Admin' }, { title: 'Sản phẩm' }]} />
               <Tabs defaultActiveKey="products" items={[
                  { key: 'products', label: <span><FireOutlined />Sản phẩm Mới</span> },
                  { key: 'favourites', label: <span><StarOutlined />Khách Yêu Thích</span> },
                  { key: 'menus', label: <span><AppstoreOutlined />Menu Bánh</span> },
               ]} onChange={setCollectionType} style={{marginBottom: 20}} />
               <Button type="primary" icon={<PlusOutlined />} onClick={openAddProductModal} style={{ marginBottom: 20 }}>Thêm Bánh Mới</Button>
               <Table dataSource={productData} columns={productColumns} rowKey="_id" />
            </div>
          )}

          {selectedKey === 'news' && (
            <div style={{ padding: 24, background: '#fff', minHeight: 360 }}>
                <Breadcrumb style={{ margin: '0 0 16px 0' }} items={[{ title: 'Admin' }, { title: 'Tin tức' }]} />
                <Button type="primary" icon={<PlusOutlined />} onClick={() => { setEditingNews(null); form.resetFields(); setIsNewsModalOpen(true); }} style={{ marginBottom: 20 }}>
                Viết bài mới
                </Button>
                <Table dataSource={newsData} columns={newsColumns} rowKey="_id" />
            </div>
          )}
        </Content>
      </Layout>

      
      <InvoiceModal 
        open={isInvoiceOpen} 
        onCancel={() => setIsInvoiceOpen(false)} 
        order={selectedOrder} 
      />

     <Modal 
        title={editingProduct ? "Sửa sản phẩm" : "Thêm sản phẩm"} 
        open={isProductModalOpen} 
        onCancel={() => setIsProductModalOpen(false)} 
        footer={null}
      >
         <Form form={form} onFinish={handleSaveProduct} layout="vertical">
             <Form.Item name="name" label="Tên bánh" rules={[{ required: true }]}><Input /></Form.Item>
             <Form.Item name="price" label="Giá" rules={[{ required: true }]}><Input type="number" /></Form.Item>
             <Form.Item name="image" label="Link ảnh" rules={[{ required: true }]}><Input /></Form.Item>
             
             {collectionType === 'menus' && (
                <Form.Item 
                  name="category" 
                  label="Danh mục bánh" 
                  rules={[{ required: true, message: 'Vui lòng chọn danh mục!' }]}
                >
                   <Select options={categoryOptions} placeholder="Chọn loại bánh (VD: Mousse, Sweetbox...)" />
                </Form.Item>
             )}

             <Form.Item name="description" label="Mô tả">
                <Input.TextArea rows={3} placeholder="Mô tả ngắn về bánh..." />
             </Form.Item>

             <Button type="primary" htmlType="submit" block>
               {editingProduct ? "Cập nhật" : "Lưu lại"}
             </Button>
         </Form>
      </Modal>

      <Modal title={editingNews ? "Chỉnh sửa tin tức" : "Thêm tin tức mới"} open={isNewsModalOpen} onCancel={() => setIsNewsModalOpen(false)} footer={null} width={800}>
        <Form form={form} onFinish={handleSaveNews} layout="vertical">
            <Form.Item name="title" label="Tiêu đề bài viết" rules={[{ required: true }]}><Input /></Form.Item>
            <Form.Item name="image" label="Link ảnh đại diện" rules={[{ required: true }]}><Input /></Form.Item>
            <Form.Item name="description" label="Mô tả ngắn" rules={[{ required: true }]}><Input.TextArea rows={2} showCount maxLength={200} /></Form.Item>
            <Form.Item name="content" label="Nội dung chi tiết" rules={[{ required: true }]}><Input.TextArea rows={10} /></Form.Item>
            <Button type="primary" htmlType="submit" block>Lưu bài viết</Button>
        </Form>
      </Modal>

    </Layout>
  );
};

export default AdminDashboard;