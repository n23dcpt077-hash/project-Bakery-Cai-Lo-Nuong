import React from 'react';
import { Modal, Button } from 'antd';
import { PrinterOutlined } from '@ant-design/icons';
import styled from 'styled-components';

const InvoiceWrapper = styled.div`
  padding: 20px;
  background: #fff;
  color: #333;
  font-family: 'Arial', sans-serif;

  /* CSS để khi in chỉ in phần này */
  @media print {
    body * {
      visibility: hidden;
    }
    #invoice-content, #invoice-content * {
      visibility: visible;
    }
    #invoice-content {
      position: absolute;
      left: 0;
      top: 0;
      width: 100%;
    }
  }
`;

const SectionTitle = styled.h3`
  font-size: 16px;
  text-transform: uppercase;
  margin: 20px 0 10px;
  font-weight: bold;
  border-bottom: 2px solid #eee;
  padding-bottom: 5px;
`;

const OrderTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;

  th, td {
    padding: 10px 0;
    text-align: left;
    border-bottom: 1px solid #eee;
    font-size: 14px;
  }
  
  th { text-transform: uppercase; }
  .amount { text-align: right; font-weight: bold; }
  .total-row td { font-size: 16px; color: #d0021b; border: none; }
`;

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
};

const InvoiceModal = ({ open, onCancel, order }) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal
      open={open}
      onCancel={onCancel}
      width={800}
      footer={[
        <Button key="close" onClick={onCancel}>Đóng</Button>,
        <Button key="print" type="primary" icon={<PrinterOutlined />} onClick={handlePrint}>In hóa đơn</Button>
      ]}
      style={{ top: 20 }}
    >
      <div id="invoice-content">
        <InvoiceWrapper>
          <div style={{ textAlign: 'center', marginBottom: 20 }}>
            <h2 style={{ color: '#d0021b', margin: 0 }}>CÁI LÒ NƯỚNG</h2>
            <p>HÓA ĐƠN BÁN LẺ</p>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 20 }}>
            <div>
              <strong>Khách hàng:</strong> {order.customer?.name}<br />
              <strong>SĐT:</strong> {order.customer?.phone}<br />
              <strong>Địa chỉ:</strong> {order.customer?.address}
            </div>
            <div style={{ textAlign: 'right' }}>
              <strong>Mã đơn:</strong> #{order._id || order.id}<br />
              <strong>Ngày:</strong> {new Date(order.createdAt || order.date).toLocaleDateString('vi-VN')}<br />
              <strong>Thanh toán:</strong> {order.paymentMethod === 'banking' ? 'Chuyển khoản' : 'Tiền mặt'}
            </div>
          </div>

          <SectionTitle>Chi tiết đơn hàng</SectionTitle>
          <OrderTable>
            <thead>
              <tr>
                <th>Sản phẩm</th>
                <th>SL</th>
                <th>Đơn giá</th>
                <th className="amount">Thành tiền</th>
              </tr>
            </thead>
            <tbody>
              {order.products?.map((item, index) => (
                <tr key={index}>
                  <td>{item.name}</td>
                  <td>{item.quantity}</td>
                  <td>{formatCurrency(item.price)}</td>
                  <td className="amount">{formatCurrency(item.price * item.quantity)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="3">Tạm tính:</td>
                <td className="amount">{formatCurrency(order.amounts?.subtotal || 0)}</td>
              </tr>
              <tr>
                <td colSpan="3">Phí giao hàng:</td>
                <td className="amount">{formatCurrency(order.amounts?.ship || 0)}</td>
              </tr>
              <tr className="total-row">
                <td colSpan="3"><strong>TỔNG CỘNG:</strong></td>
                <td className="amount">{formatCurrency(order.amounts?.total || 0)}</td>
              </tr>
            </tfoot>
          </OrderTable>

          {order.customer?.note && (
            <div style={{ marginTop: 20, fontStyle: 'italic', background: '#f9f9f9', padding: 10 }}>
              <strong>Ghi chú:</strong> {order.customer.note}
            </div>
          )}
          
          <div style={{ marginTop: 40, textAlign: 'center', fontSize: 12 }}>
            <p>Cảm ơn quý khách đã mua hàng!</p>
          </div>
        </InvoiceWrapper>
      </div>
    </Modal>
  );
};

export default InvoiceModal;