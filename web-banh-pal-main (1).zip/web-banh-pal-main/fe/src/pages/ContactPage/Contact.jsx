import React from 'react';
import PageTitle from '../../components/PageTitle/Pagetitle';
import { 
  Container, 
  HeaderTitle, 
  Section, 
  SectionTitle, 
  BranchList, 
  BranchItem, 
  ContactInfo,
  OpeningBox,
  OpeningTitle,
  OpeningSubtitle,
  OpeningTime
} from './style';

const Contact = () => {
  const contactIcon = "https://cdn-icons-png.flaticon.com/512/3059/3059502.png";

  return (
    <Container>
      <PageTitle 
        title="Liên hệ - Hệ thống cửa hàng" 
        icon={contactIcon}
        showTitle={false}
      />

      <HeaderTitle>Hệ thống cửa hàng Cái Lò Nướng</HeaderTitle>

      <Section>
        <SectionTitle>Các chi nhánh của Cái Lò Nướng:</SectionTitle>
        <BranchList>
          <BranchItem>
            <strong>CN1:</strong> 15K Nguyễn Thị Minh Khai – P. Bến Nghé – Quận 1
          </BranchItem>
          <BranchItem>
            <strong>CN2:</strong> 173 Nguyễn Thái Học – P. Phạm Ngũ Lão – Quận 1
          </BranchItem>
          <BranchItem>
            <strong>CN3:</strong> 29 Lê Văn Việt – P. Hiệp Phú – TP Thủ Đức
          </BranchItem>
          <BranchItem>
            <strong>CN4:</strong> 186 Quang Trung – Phường 10 – Quận Gò Vấp
          </BranchItem>
          <BranchItem>
            <strong>CN5:</strong> 477 Nguyễn Thị Thập – P. Tân Phong – Quận 7
          </BranchItem>
          <BranchItem>
            <strong>CN6:</strong> 38 Hoa Mai - Phường 2 - Quận Phú Nhuận
          </BranchItem>
          <BranchItem>
            <strong>CN7:</strong> 2A Ba Gia - P.7 – Quận Tân Bình
          </BranchItem>
        </BranchList>
      </Section>

      <Section>
        <SectionTitle>Thông tin liên hệ:</SectionTitle>
        <ContactInfo>
          <p>Hotline: <span>028.8888.3388</span></p>
          <p>Phản hồi chất lượng dịch vụ: <span>028.8888.3388</span></p>
        </ContactInfo>
      </Section>

    <OpeningBox>
        <OpeningTitle>Giờ mở cửa</OpeningTitle>
        <OpeningSubtitle>tất cả các ngày trong tuần</OpeningSubtitle>
        
        <OpeningTime>
          <span>Thứ Hai - Chủ nhật</span>
          <span>8:00 - 22:00</span>
        </OpeningTime>
      </OpeningBox>
    </Container>
  );
};

export default Contact;