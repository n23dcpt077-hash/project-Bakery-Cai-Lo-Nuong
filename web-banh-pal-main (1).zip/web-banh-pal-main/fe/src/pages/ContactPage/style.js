import styled from 'styled-components';

export const Container = styled.div`
  max-width: 800px;
  margin: 50px auto;
  padding: 0 20px;
  min-height: 60vh;
`;

export const HeaderTitle = styled.h2`
  color: #002c1b;
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 30px;
  text-transform: uppercase;
  text-align: center;
  position: relative;

  /* Tạo gạch chân nhỏ dưới tiêu đề */
  &::after {
    content: '';
    display: block;
    width: 60px;
    height: 3px;
    background-color: #cfa144;
    margin: 15px auto 0;
  }
`;

export const Section = styled.div`
  margin-bottom: 40px;
`;

export const SectionTitle = styled.h3`
  font-size: 18px;
  color: #333;
  margin-bottom: 20px;
  font-weight: 600;
`;

export const BranchList = styled.ul`
  list-style: none; /* Bỏ dấu chấm tròn mặc định */
  padding: 0;
`;

export const BranchItem = styled.li`
  font-size: 16px;
  color: #555;
  margin-bottom: 15px;
  line-height: 1.6;
  border-bottom: 1px dashed #eee; /* Đường kẻ mờ ngăn cách */
  padding-bottom: 10px;

  /* Tô đậm phần tên chi nhánh (CN1, CN2...) */
  strong {
    color: #002c1b;
    font-weight: 700;
    margin-right: 8px;
  }
`;

export const ContactInfo = styled.div`
  background-color: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
  border-left: 5px solid #cfa144; /* Viền vàng bên trái làm điểm nhấn */

  p {
    margin-bottom: 10px;
    font-size: 16px;
    color: #333;

    &:last-child {
      margin-bottom: 0;
    }
  }

  /* Tô màu vàng đậm cho số điện thoại */
  span {
    color: #cfa144;
    font-weight: bold;
    font-size: 18px;
  }
`;


export const OpeningBox = styled.div`
  margin-top: 50px;
  border: 2px dashed #ccc; /* Viền nét đứt màu xám */
  padding: 40px;
  text-align: center;
  border-radius: 8px;
  background-color: #fff;
`;

export const OpeningTitle = styled.h3`
  font-size: 24px;
  font-weight: 700;
  color: #002c1b; /* Màu xanh đậm */
  margin-bottom: 10px;
  text-transform: none;
`;

export const OpeningSubtitle = styled.p`
  font-family: "Brush Script MT", cursive; /* Font chữ viết tay/nghiêng */
  font-size: 22px;
  color: #cfa144; /* Màu vàng */
  margin-bottom: 20px;
  font-style: italic;
`;

export const OpeningTime = styled.div`
  font-size: 18px;
  color: #333;
  display: flex;
  justify-content: center;
  gap: 30px; /* Khoảng cách giữa "Thứ 2..." và "8:00..." */
  font-weight: 500;
`;