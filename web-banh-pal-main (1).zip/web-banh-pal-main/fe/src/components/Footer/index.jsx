import React from 'react';
import {
  FooterContainer,
  FooterContent,
  TopSection,
  CompanyInfo,
  GovBadge,
  BottomSection,
  CopyrightText,
  FooterLinks,
  StyledFooterLink
} from './style';

const Footer = () => {
  return (
    <FooterContainer>
      <FooterContent>
        {/* Phần trên: Thông tin công ty & Logo Bộ Công Thương */}
        <TopSection>
          <CompanyInfo>
            <h3>Công ty TNHH Cái Lò Nướng</h3>
            <p>2A Ba Gia, Phường 7, quận Tân Bình, Thành phố Hồ Chí Minh</p>
            <p>Số điện thoại: 028.8888.3388</p>
            <p>Email: sale@cailonuong.vn</p>
            <p>Giấy chứng nhận đăng ký kinh doanh: 0315630862</p>
            <p>Mã số doanh nghiệp: 0315630862. Giấy chứng nhận đăng ký doanh nghiệp do Sở Kế hoạch và Đầu tư Thành phố Hồ Chí Minh cấp lần đầu ngày 16/04/2019.</p>
          </CompanyInfo>

          <GovBadge>
            {/* Bạn thay link ảnh thật của bộ công thương vào đây */}
            <a href="https://cailonuong.com/wp-content/uploads/2024/05/logoSaleNoti.png" target="_blank" rel="noopener noreferrer">
              <img 
                src="https://cailonuong.com/wp-content/uploads/2024/05/logoSaleNoti.png" 
                alt="Đã thông báo bộ công thương" 
              />
            </a>
          </GovBadge>
        </TopSection>

        {/* Phần dưới: Copyright & Links */}
        <BottomSection>
          <CopyrightText>
            © 2023 Cái Lò Nướng.
          </CopyrightText>
          
          <FooterLinks>
            <StyledFooterLink to="/ship">Chính sách giao hàng</StyledFooterLink>
            <StyledFooterLink to="/return">Chính sách trả hàng – hoàn tiền</StyledFooterLink>
            <StyledFooterLink to="/payment">Phương thức thanh toán</StyledFooterLink>
            <StyledFooterLink to="/terms">Điều khoản & điều kiện thanh toán</StyledFooterLink>
            <StyledFooterLink to="/privacy">Bảo vệ thông tin cá nhân người tiêu dùng</StyledFooterLink>
            <StyledFooterLink to="/contact">Thông tin liên hệ</StyledFooterLink>
            <StyledFooterLink to="/store">Cửa hàng</StyledFooterLink>
          </FooterLinks>
        </BottomSection>
      </FooterContent>
    </FooterContainer>
  );
};

export default Footer;