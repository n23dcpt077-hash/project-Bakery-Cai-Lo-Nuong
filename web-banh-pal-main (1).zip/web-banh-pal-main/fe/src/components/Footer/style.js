import styled from 'styled-components';
import { Link } from 'react-router-dom';

export const FooterContainer = styled.footer`
  background-color: #10212e; /* Màu nền xanh đen đậm giống ảnh */
  color: #ffffff;
  padding: 40px 0 20px 0;
  font-size: 14px;
  line-height: 1.6;
`;

export const FooterContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
`;

export const TopSection = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  padding-bottom: 30px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1); // Đường gạch ngang mờ

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 20px;
  }
`;

export const CompanyInfo = styled.div`
  flex: 2;

  h3 {
    font-size: 16px;
    font-weight: bold;
    margin-bottom: 10px;
    text-transform: uppercase;
  }

  p {
    margin-bottom: 5px;
    color: #e0e0e0; // Màu chữ hơi xám trắng
    font-size: 13px;
  }
`;

export const GovBadge = styled.div`
  flex: 1;
  display: flex;
  justify-content: flex-end;

  img {
    width: 150px; // Kích thước logo bộ công thương
    height: auto;
    cursor: pointer;
  }

  @media (max-width: 768px) {
    justify-content: flex-start;
  }
`;

export const BottomSection = styled.div`
  padding-top: 20px;
  text-align: center;
  color: #a0a0a0;
`;

export const CopyrightText = styled.div`
  margin-bottom: 15px;
  font-size: 14px;
  color: #ffffff;
`;

export const FooterLinks = styled.div`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  gap: 15px;
  
  /* Tạo đường gạch dọc giữa các link (nếu muốn giống 1 số web) */
  /* Hoặc chỉ để khoảng cách như ảnh mẫu */
`;

export const StyledFooterLink = styled(Link)`
  color: #8898aa;
  text-decoration: none;
  font-size: 13px;
  transition: color 0.3s ease;

  &:hover {
    color: #ffffff;
  }

  /* Thêm dấu gạch đứng ngăn cách ngoại trừ phần tử cuối */
  &:not(:last-child)::after {
    content: '|';
    margin-left: 15px;
    color: #445566;
  }
`;