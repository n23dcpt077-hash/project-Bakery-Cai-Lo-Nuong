import React, { useState, useEffect} from 'react';
import { Link, NavLink } from 'react-router-dom';
import styled from 'styled-components';
import { FaBars, FaTimes } from 'react-icons/fa';


const Nav = styled.nav`
  background: #4a6735;
  height: 80px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 50px;
  position: relative; 
  z-index: 999; /* Luôn nổi lên trên cùng */
  box-shadow: 0 2px 5px rgba(0,0,0,0.2);

  @media (max-width: 768px) {
    padding: 0 20px;
  }
`;

const LogoLink = styled(Link)`
  text-decoration: none;
  cursor: pointer;
  z-index: 1000; /* Logo luôn bấm được */
`;

const MobileIcon = styled.div`
  display: none;

  @media (max-width: 768px) {
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    transform: translate(-50%, 60%);
    font-size: 1.8rem;
    cursor: pointer;
    color: white;
    z-index: 1000;
  }
`;

const NavMenu = styled.div`
  display: flex;
  align-items: center;
  gap: 20px;

  /* --- GIAO DIỆN MOBILE & LANDSCAPE (548x285) --- */
  @media (max-width: 768px) {
    display: flex;
    flex-direction: column;
    width: 100%;
    /* Dùng fixed thay vì absolute để menu luôn phủ kín màn hình */
    position: fixed; 
    top: 80px; /* Bắt đầu ngay dưới header */
    left: ${({ $isOpen }) => ($isOpen ? '0' : '-100%')};
    height: calc(100vh - 80px); /* Chiều cao = Toàn màn hình - Header */
    
    background-color: #4a6735;
    transition: all 0.4s ease;
    opacity: 1;
    z-index: 998;
    
    /* QUAN TRỌNG: Cho phép cuộn dọc nếu màn hình thấp (285px) */
    overflow-y: auto; 
    padding-bottom: 50px; /* Khoảng trống dưới cùng để dễ vuốt */
    align-items: stretch; /* Kéo dãn item ra full chiều ngang */
    gap: 0;
    overscroll-behavior: contain;
  }
`;

const NavItem = styled.div`
  height: 80px;
  display: flex;
  align-items: center;
  position: relative; /* Để định vị dropdown desktop */

  @media (max-width: 768px) {
    height: auto; /* Trên mobile chiều cao tự do */
    flex-direction: column;
    width: 100%;
    align-items: flex-start;
  }

  /* Logic Hover Desktop: Hover vào NavItem thì hiện Dropdown */
  @media (min-width: 769px) {
    &:hover > div {
      display: block;
      opacity: 1;
      visibility: visible;
    }
  }
`;

const NavLinkStyled = styled(NavLink)`
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  text-transform: uppercase;
  font-weight: 600;
  font-size: 13px;
  padding: 0 1rem;
  height: 100%;
  display: flex;
  align-items: center;
  cursor: pointer;

  &:hover, &.active {
    color: #fff;
  }

  /* Style Mobile */
  @media (max-width: 768px) {
    width: 100%;
    padding: 20px;
    justify-content: flex-start; /* Canh trái */
    border-bottom: 1px solid rgba(255,255,255,0.1);
    
    &:hover {
      background-color: #3e572b;
      color: #cfa144;
    }
  }
`;

const DropdownContent = styled.div`
  /* DESKTOP */
  display: none;
  position: absolute;
  top: 80px;
  left: 0;
  background-color: #3e572b;
  min-width: 250px;
  z-index: 1001;
  box-shadow: 0 8px 16px rgba(0,0,0,0.2);
  border-top: 3px solid #cfa144;

 
  @media (max-width: 768px) {
    display: block; 
    position: static;
    width: 100%;
    box-shadow: none;
    border-top: none;
    background-color: #354a25; 
    padding-left: 0;
  }
`;

const DropdownLink = styled(NavLink)`
  display: block;
  color: #fff;
  padding: 12px 20px;
  text-decoration: none;
  font-size: 14px;
  border-bottom: 1px solid rgba(255,255,255,0.05);

  &:hover {
    background-color: #2e4020;
    color: #cfa144;
    padding-left: 25px; 
  }

  @media (max-width: 768px) {
    padding-left: 40px; 
    border-bottom: 1px solid rgba(255,255,255,0.05);
    &:hover { padding-left: 40px; }
  }
`;



const Navbar = () => {
  const [click, setClick] = useState(false);

  const handleClick = () => setClick(!click);
  
  const closeMobileMenu = () => setClick(false);
  useEffect(() => {
    if (click) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [click]);
  return (
    <Nav>
      <LogoLink to="/" onClick={closeMobileMenu}>
        <img 
          src="https://cailonuong.com/wp-content/uploads/2024/04/logo.png#30392" 
          alt="Cai Lo Nuong" 
          style={{ height: '60px', width: 'auto' }}
        />
      </LogoLink>

      <MobileIcon onClick={handleClick}>
        {click ? <FaTimes /> : <FaBars />}
      </MobileIcon>

      <NavMenu $isOpen={click}>
        
        <NavItem>
          <NavLinkStyled to="/" end onClick={closeMobileMenu}>
            Trang chủ
          </NavLinkStyled>
        </NavItem>

        <NavItem>
          <NavLinkStyled to="/menu-banh" onClick={closeMobileMenu}>
            Menu Bánh 
          </NavLinkStyled>
          
          <DropdownContent>
            <DropdownLink to="/menu-banh/sweetbox" onClick={closeMobileMenu}>Sweetbox</DropdownLink>
            <DropdownLink to="/menu-banh/sweetin" onClick={closeMobileMenu}>Sweetin</DropdownLink>
            <DropdownLink to="/menu-banh/mousse" onClick={closeMobileMenu}>Mousse</DropdownLink>
            <DropdownLink to="/menu-banh/entremet" onClick={closeMobileMenu}>Entremet</DropdownLink>
            <DropdownLink to="/menu-banh/kem-bap" onClick={closeMobileMenu}>Kem Bắp</DropdownLink>
            <DropdownLink to="/menu-banh/banh-mi" onClick={closeMobileMenu}>Bánh Mì</DropdownLink>
          </DropdownContent>
        </NavItem>

        <NavItem>
          <NavLinkStyled to="/ship" onClick={closeMobileMenu}>Giao hàng</NavLinkStyled>
        </NavItem>

        <NavItem>
          <NavLinkStyled to="/contact" onClick={closeMobileMenu}>Liên hệ</NavLinkStyled>
        </NavItem>
        
        <NavItem>
          <NavLinkStyled to="/store" onClick={closeMobileMenu}>Cửa hàng</NavLinkStyled>
        </NavItem>

        <NavItem>
          <NavLinkStyled to="/news" onClick={closeMobileMenu}>Tin tức</NavLinkStyled>
        </NavItem>

      </NavMenu>
    </Nav>
  );
};

export default Navbar;