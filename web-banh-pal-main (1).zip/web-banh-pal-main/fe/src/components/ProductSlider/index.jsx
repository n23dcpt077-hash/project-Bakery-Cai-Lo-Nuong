import React, { useState, useEffect } from 'react'; // Thêm useRef nếu cần, nhưng ở đây dùng state là đủ
import axios from 'axios';

// 1. Import Swiper
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import { Link } from 'react-router-dom';
// 2. Import CSS Swiper
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

// 3. Import Styled Components (Nhớ import thêm ButtonGroup và NavButton vừa tạo)
import { 
  SectionContainer, 
  SectionHeader, 
  Card, 
  ProductImage, 
  ProductInfo,
  ButtonGroup, // <--- Mới
  NavButton    // <--- Mới
} from './style';

const ProductSlider = () => {
  const [products, setProducts] = useState([]);
  
  // Tạo state để lưu instance (bộ điều khiển) của Swiper
  const [swiperRef, setSwiperRef] = useState(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/products');
        setProducts(response.data);
      } catch (error) {
        console.error('Lỗi:', error);
      }
    };
    fetchProducts();
  }, []);

  return (
    <div>
      <SectionContainer>
        <SectionHeader>
          <h2>Sản phẩm mới</h2>

          {/* --- PHẦN MỚI: 2 Nút Vuông nằm ngang hàng Title --- */}
          <ButtonGroup>
            {/* Nút lùi: Gọi lệnh slidePrev() */}
            <NavButton onClick={() => swiperRef?.slidePrev()}>
              &lt; {/* Dấu nhỏ hơn (<) */}
            </NavButton>

            {/* Nút tiến: Gọi lệnh slideNext() */}
            <NavButton onClick={() => swiperRef?.slideNext()}>
              &gt; {/* Dấu lớn hơn (>) */}
            </NavButton>
          </ButtonGroup>
          {/* -------------------------------------------------- */}
        </SectionHeader>

        {products.length > 0 && (
          <Swiper
            // Quan trọng: Gán bộ điều khiển ra biến state bên ngoài
            onSwiper={setSwiperRef} 
            
            modules={[Navigation, Pagination, Autoplay]}
            autoplay={{
              delay: 1000, // Thời gian chờ: 3000ms = 3 giây
              disableOnInteraction: false, // Vẫn tiếp tục tự chạy sau khi người dùng tương tác (vuốt/bấm)
              pauseOnMouseEnter: true, // (Tùy chọn) Tạm dừng khi rê chuột vào để khách dễ xem
            }}
            spaceBetween={20}
            slidesPerView={4}
            slidesPerGroup={1} // Mình chỉnh lại thành 1 để chuyển mượt hơn, bạn thích để 4 cũng được
            
            navigation={false} // TẮT navigation mặc định của Swiper đi
            
            loop={true}
            breakpoints={{
              320: { slidesPerView: 1 },
              768: { slidesPerView: 2 },
              1024: { slidesPerView: 4 },
            }}
          >
            {products.map((product) => (
              <SwiperSlide key={product._id}>
                <Card>
                  <Link to={`/product/${product._id}`} state={{ collection: 'products' }}
            style={{ color: 'inherit', textDecoration: 'none' }} >
                  <ProductImage>
                    <img src={product.image} alt={product.name} />
                  </ProductImage>
                  <ProductInfo>
                    <h3>{product.name}</h3>
                    <p>{product.price?.toLocaleString('vi-VN')} ₫</p>
                  </ProductInfo>
                  </Link>
                </Card>
              </SwiperSlide>
            ))}
          </Swiper>
        )}
      </SectionContainer>
    </div>
  );
};

export default ProductSlider;