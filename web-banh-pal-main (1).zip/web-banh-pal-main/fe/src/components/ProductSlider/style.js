import styled from 'styled-components';

export const SectionContainer = styled.div`
  max-width: 1200px;
  margin: 50px auto;
  padding: 0 20px;
`;

export const SectionHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;

  h2 {
    font-size: 24px;
    font-weight: bold;
    color: #002c1b; // Màu xanh đậm
    text-transform: uppercase;
  }
`;

export const Card = styled.div`
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  transition: all 0.3s ease;
  cursor: pointer;

  &:hover {
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    transform: translateY(-5px);
  }
`;

export const ProductImage = styled.div`
  width: 100%;
  height: 250px; // Chiều cao cố định cho ảnh đều nhau
  overflow: hidden;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.5s ease;
  }

  ${Card}:hover & img {
    transform: scale(1.1); // Zoom ảnh nhẹ khi hover
  }
`;

export const ProductInfo = styled.div`
  padding: 15px 0;

  h3 {
    font-size: 16px;
    font-weight: 600;
    margin-bottom: 10px;
    color: #333;
    line-height: 1.4;
    height: 44px; // Giới hạn chiều cao tên bánh (2 dòng)
    overflow: hidden;
  }

  p {
    color: #cfa144; // Màu vàng giống trong ảnh
    font-weight: bold;
    font-size: 16px;
  }
`;
// ... Các code cũ giữ nguyên ...

// Nhóm chứa 2 nút, dùng flex để xếp ngang
export const ButtonGroup = styled.div`
  display: flex;
  gap: 10px; // Khoảng cách giữa 2 nút
`;

// Style cho nút hình vuông
export const NavButton = styled.button`
  width: 40px;  // Chiều rộng
  height: 40px; // Chiều cao bằng chiều rộng -> Hình vuông
  border: 1px solid #ccc;
  background-color: transparent;
  color: #333;
  font-size: 20px;
  cursor: pointer;
  display: flex;            // Để căn giữa dấu mũi tên
  justify-content: center;  // Căn giữa ngang
  align-items: center;      // Căn giữa dọc
  transition: all 0.3s ease;

  &:hover {
    background-color: #002c1b; // Màu xanh giống title khi hover
    color: white;
    border-color: #002c1b;
  }
`;