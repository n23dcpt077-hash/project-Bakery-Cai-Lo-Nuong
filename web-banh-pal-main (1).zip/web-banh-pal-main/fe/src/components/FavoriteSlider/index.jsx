import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay} from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import { Link } from 'react-router-dom';
// Tái sử dụng style từ ProductSlider cũ để đồng bộ giao diện
// Dấu .. đi ra ngoài thư mục FavoriteSlider, vào ProductSlider lấy file style
import { 
  SectionContainer, SectionHeader, Card, ProductImage, ProductInfo, ButtonGroup, NavButton 
} from '../ProductSlider/style'; 

const FavoriteSlider = () => {
  const [products, setProducts] = useState([]);
  const [swiperRef, setSwiperRef] = useState(null);

  useEffect(() => {
    const fetchFavourites = async () => {
      try {
        // Gọi API favorites
        const response = await axios.get('http://localhost:5000/api/favourites');
        setProducts(response.data);
      } catch (error) {
        console.error('Lỗi:', error);
      }
    };
    fetchFavourites();
  }, []);

  return (
    <SectionContainer>
      <SectionHeader>
        {/* Đổi tiêu đề */}
        <h2 style={{ color: '#d32f2f' }}>Được nhiều khách hàng yêu thích</h2>
        
        <ButtonGroup>
          <NavButton onClick={() => swiperRef?.slidePrev()}>&lt;</NavButton>
          <NavButton onClick={() => swiperRef?.slideNext()}>&gt;</NavButton>
        </ButtonGroup>
      </SectionHeader>

      {products.length > 0 ? (
        <Swiper
          onSwiper={setSwiperRef}
          modules={[Navigation, Pagination, Autoplay]}
          autoplay={{
              delay: 1000, // Thời gian chờ: 3000ms = 3 giây
              disableOnInteraction: false, // Vẫn tiếp tục tự chạy sau khi người dùng tương tác (vuốt/bấm)
              pauseOnMouseEnter: true, // (Tùy chọn) Tạm dừng khi rê chuột vào để khách dễ xem
            }}
          spaceBetween={20}
          slidesPerView={4}
          loop={true}
          navigation={false}
          breakpoints={{
            320: { slidesPerView: 1 },
            768: { slidesPerView: 2 },
            1024: { slidesPerView: 4 },
          }}
        >
          {products.map((product) => (
            <SwiperSlide key={product._id}>
              <Card>
                <Link 
              to={`/product/${product._id}`} 
  state={{ collection: 'favourites' }}
              style={{ color: 'inherit', textDecoration: 'none' }}
          >
                <ProductImage>
                  <img src={product.image} alt={product.name} />
                  {/* Thêm cái nhãn Hot cho khác biệt xíu */}
                  <div style={{
                    position: 'absolute', top: 10, right: 10, 
                    background: 'red', color: 'white', padding: '2px 8px', 
                    borderRadius: '4px', fontSize: '12px', fontWeight: 'bold'
                  }}>HOT</div>
                </ProductImage>
                <ProductInfo>
                  <h3>{product.name}</h3>
                  <p>{product.price?.toLocaleString('vi-VN')} ₫</p>
                </ProductInfo>
                </Link>
              </Card>
            </SwiperSlide>
          ))}
        </Swiper>
      ) : (
        <p style={{ textAlign: 'center', color: '#999' }}>Chưa có sản phẩm yêu thích nào.</p>
      )}
    </SectionContainer>
  );
};

export default FavoriteSlider;