import React from 'react';
import Navbar from '../../Navbar/Navbar'; 
import Footer from '../../Footer/index';

const DefaultLayout = ({ children }) => {
  return (
    <div>
     
      <Navbar />
      
     
      <div className="container">
        {children}
      </div>
      <Footer />
    </div>
  );
};

export default DefaultLayout;