import styled from 'styled-components';

export const TitleWrapper = styled.div`
  display: flex;
  align-items: center;       /* Căn giữa dọc */
  gap: 15px;                 /* Khoảng cách giữa Icon và Chữ */
  margin-bottom: 30px;       /* Cách lề dưới để đẩy nội dung ra xa */
  padding-bottom: 15px;      /* Khoảng đệm dưới */
  border-bottom: 1px solid #eee; /* Đường kẻ mờ toàn chiều rộng (tùy chọn) */
`;

export const MainTitle = styled.h1`
  font-size: 26px;
  font-weight: 700;
  color: #002c1b;            /* Màu xanh đậm chủ đạo */
  text-transform: uppercase; /* Chữ in hoa */
  margin: 0;
  position: relative;        /* Để căn chỉnh vạch vàng bên dưới */
  letter-spacing: 1px;       /* Giãn chữ ra xíu cho thoáng */

  /* Tạo vạch vàng nghệ thuật dưới chân chữ */
  &::after {
    content: '';
    position: absolute;
    bottom: -16px;           /* Đẩy xuống đè lên viền của Wrapper */
    left: 0;
    width: 60px;             /* Chiều dài của vạch vàng */
    height: 4px;             /* Độ dày của vạch */
    background-color: #cfa144; /* Màu vàng nghệ */
    border-radius: 2px;      /* Bo tròn góc vạch cho mềm mại */
  }
`;

export const TitleIcon = styled.img`
  width: 40px;               /* Kích thước icon */
  height: 40px;
  object-fit: contain;       /* Đảm bảo ảnh không bị méo */
`;