import React from 'react';

import { TitleWrapper, MainTitle, TitleIcon } from './style';

const PageTitle = ({ title, icon, showTitle = true }) => {
  
  return (
    <>
      

      {showTitle && (
        <TitleWrapper>
          {icon && <TitleIcon src={icon} alt="icon" />}
          <MainTitle>{title}</MainTitle>
        </TitleWrapper>
      )}
    </>
  );
};

export default PageTitle;