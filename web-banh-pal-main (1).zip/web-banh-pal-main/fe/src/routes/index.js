import { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Home from "../pages/HomePage/Home";
import Contact from "../pages/ContactPage/Contact";
import AdminDashboard from "../pages/Admin/Dashboard";
import PrivateRoute from "../components/PrivateRoute";
import Login from "../pages/Admin/Login";
import ProductDetail from "../pages/ProductDetail/index";
import Ship from "../pages/Ship/Ship";
import Cart from "../pages/Cart/index";
import Store from "../pages/Store/StorePage";
import MenuPage from "../pages/MenuPage/index";
import Loyalty from "../pages/Loyalty";
import Payment from "../pages/Payment/index";
import PostPay from "../pages/PostPay/index";
import NewsPage from "../pages/News/index";
import TermsPage from "../pages/Terms/TermsPage";
import PrivacyPolicy from "../pages/PrivacyPolicy/PrivacyPolicy";
import NewsDetail from "../pages/NewsDetail/NewsDetail";
import ReturnPolicy from "../pages/ReturnPolicy/ReturnPolicy";
const DynamicTitle = () => {
  const location = useLocation();

  useEffect(() => {
    const path = location.pathname;
    let title = "Cái Lò Nướng";

    if (path === "/") {
      title = "Trang chủ";
    } else if (path === "/contact") {
      title = "Liên hệ";
    } else if (path === "/login") {
      title = "Đăng nhập quản trị";
    } else if (path.startsWith("/admin")) {
      title = "Trang quản trị (Admin)";
    } else if (path === "/cart") {
      title = "Giỏ hàng của bạn";
    } else if (path === "/ship") {
      title = "Thông tin giao hàng";
    } else if (path === "/store") {
      title = "Hệ thống cửa hàng";
    } else if (path.startsWith("/menu-banh")) {
      title = "Menu bánh";
    } else if (path === "/loyalty") {
      title = "Khách hàng thân thiết";
    } else if (path === "/payment") {
      title = "Thanh toán";
    } else if (path === "/postpay") {
      title = "Đặt hàng thành công";
    } else if (path === "/news") {
      title = "Tin tức và Khuyến mãi";
    } else if (path === "/terms") {
      title = "Điều khoản sử dụng";
    }
    else if (path === "/privacy") {
      title = "Bảo vệ thông tin cá nhân người tiêu dùng";
    }
    else if (path === "/return") {
      title = " Chính sách trả hàng – hoàn tiền";
    }
    document.title = title;
  }, [location]);

  return null;
};

const AppRoutes = () => {
  return (
    <>
      {}
      <DynamicTitle />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />

        <Route element={<PrivateRoute />}>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
        </Route>

        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/ship" element={<Ship />} />
        <Route path="/store" element={<Store />} />

        <Route path="/menu-banh" element={<MenuPage />} />
        <Route path="/menu-banh/:category" element={<MenuPage />} />

        <Route path="/loyalty" element={<Loyalty />} />
        <Route path="/payment" element={<Payment />} />
        <Route path="/postpay" element={<PostPay />} />
        <Route path="/news" element={<NewsPage />} />
        <Route path="/terms" element={<TermsPage />} />
        <Route path="/privacy" element={<PrivacyPolicy/>} />
        <Route path="/news/:id" element={<NewsDetail />} />
        <Route path="/return" element={<ReturnPolicy />} />
      </Routes>
    </>
  );
};

export default AppRoutes;
