const express = require('express');
const router = express.Router();
const orderController = require('../controllers/orderController');

// Định nghĩa các đường dẫn
router.post('/', orderController.createOrder);       // Tạo đơn mới
router.get('/', orderController.getAllOrders);       // Lấy danh sách
router.put('/:id', orderController.updateOrderStatus); // Cập nhật trạng thái

module.exports = router;