const express = require('express');
const router = express.Router();
const Favourite = require('../models/Favourite');

// 1. Lấy danh sách
router.get('/', async (req, res) => {
  try {
    const favs = await Favourite.find().sort({ createdAt: -1 });
    res.json(favs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// 2. Lấy chi tiết
router.get('/:id', async (req, res) => {
  try {
    const fav = await Favourite.findById(req.params.id);
    if (!fav) return res.status(404).json({ message: 'Không tìm thấy' });
    res.json(fav);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// 3. THÊM MỚI (Quan trọng)
router.post('/', async (req, res) => {
  // Chỉ lấy name, price, image, description. KHÔNG lấy category
  const { name, price, image, description } = req.body;
  
  if (!name || !price || !image) {
    return res.status(400).json({ message: 'Thiếu thông tin (Tên, Giá, Ảnh)' });
  }

  const newFav = new Favourite({ name, price, image, description });

  try {
    const savedFav = await newFav.save();
    res.status(201).json(savedFav);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// 4. Sửa
router.put('/:id', async (req, res) => {
  try {
    const updatedFav = await Favourite.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedFav);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// 5. Xóa
router.delete('/:id', async (req, res) => {
  try {
    await Favourite.findByIdAndDelete(req.params.id);
    res.json({ message: 'Đã xóa' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;