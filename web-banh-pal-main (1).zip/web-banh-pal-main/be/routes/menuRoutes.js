const express = require('express');
const router = express.Router();
const Menu = require('../models/Menu');

// 1. Lấy danh sách (GET) - CÔNG KHAI
router.get('/', async (req, res) => {
  try {
    const menus = await Menu.find().sort({ createdAt: -1 });
    res.json(menus);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// 2. Lấy chi tiết 1 món (GET ID) - CÔNG KHAI
router.get('/:id', async (req, res) => {
  try {
    const menu = await Menu.findById(req.params.id);
    if (!menu) return res.status(404).json({ message: 'Không tìm thấy sản phẩm' });
    res.json(menu);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// 3. Thêm mới (POST) - ĐÃ BỎ BẢO MẬT
router.post('/', async (req, res) => {
  const { name, price, image, description, category } = req.body;
  
  // Kiểm tra dữ liệu cơ bản
  if (!name || !price || !image || !category) {
    return res.status(400).json({ message: 'Vui lòng điền đủ thông tin (Tên, Giá, Ảnh, Danh mục)' });
  }

  const newMenu = new Menu({ name, price, image, description, category });

  try {
    const savedMenu = await newMenu.save();
    res.status(201).json(savedMenu);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// 4. Sửa (PUT) - ĐÃ BỎ BẢO MẬT
router.put('/:id', async (req, res) => {
  try {
    const updatedMenu = await Menu.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedMenu);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// 5. Xóa (DELETE) - ĐÃ BỎ BẢO MẬT
router.delete('/:id', async (req, res) => {
  try {
    await Menu.findByIdAndDelete(req.params.id);
    res.json({ message: 'Đã xóa thành công' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;