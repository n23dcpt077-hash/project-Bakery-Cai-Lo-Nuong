const Order = require('../models/Order');
const Client = require('../models/Client');
const { sendInvoiceEmail } = require('../utils/emailService');
exports.createOrder = async (req, res) => {
  try {
    const { id, customer, products, amounts, paymentMethod, date } = req.body;

    const newOrder = new Order({
      orderCode: id,
      customer,
      products,
      amounts,
      paymentMethod,
      createdAt: date ? new Date() : Date.now()
    });

    const savedOrder = await newOrder.save();

    await Client.findOneAndUpdate(
      { phone: customer.phone },
      {
        $set: { 
          name: customer.name, 
          address: customer.address
        },
        $push: { orders: savedOrder._id }
      },
      { upsert: true, new: true }
    );
sendInvoiceEmail(savedOrder);
    res.status(201).json(savedOrder);

  } catch (error) {
    console.error("Lỗi tạo đơn:", error);
    res.status(500).json({ message: 'Lỗi server khi tạo đơn hàng' });
  }
};

exports.getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find().sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: 'Lỗi lấy danh sách đơn hàng' });
  }
};

exports.updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const orderId = req.params.id;

    const updatedOrder = await Order.findByIdAndUpdate(
      orderId,
      { status },
      { new: true }
    );

    if (!updatedOrder) {
      return res.status(404).json({ message: 'Không tìm thấy đơn hàng' });
    }

    res.json(updatedOrder);
  } catch (error) {
    res.status(500).json({ message: 'Lỗi cập nhật trạng thái' });
  }
};