const Favourite = require('../models/Favourite');

exports.getFavourites = async (req, res) => {
  try {
    const items = await Favourite.find();
    res.json(items);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.createFavourite = async (req, res) => {
  const item = new Favourite(req.body);
  try {
    const newItem = await item.save();
    res.status(201).json(newItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

exports.deleteFavourite = async (req, res) => {
  try {
    await Favourite.findByIdAndDelete(req.params.id);
    res.json({ message: 'Đã xóa sản phẩm yêu thích' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getFavouriteById = async (req, res) => {
  try {
    const item = await Favourite.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Không tìm thấy bánh trong mục yêu thích' });
    res.json(item);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateFavourite = async (req, res) => {
  try {
    const updatedItem = await Favourite.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedItem);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};