// be/seed-admin.js
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log('Kết nối DB...');
    

    // 2. Tạo admin mới
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('admin123', salt); // Pass là: admin123

    await User.create({
      username: 'admin',
      password: hashedPassword
    });

    console.log('Tạo tài khoản Admin thành công! (User: admin / Pass: admin123)');
    process.exit();
  })
  .catch(err => console.log(err));