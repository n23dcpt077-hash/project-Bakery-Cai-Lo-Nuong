const mongoose = require('mongoose');

const clientSchema = new mongoose.Schema({
  name: { type: String, required: true },
  phone: { type: String, required: true, unique: true }, 
  address: { type: String },
  email: { type: String },
  
  
  orders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Order' }],
  
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Client', clientSchema);