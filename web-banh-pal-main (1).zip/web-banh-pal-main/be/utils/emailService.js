const nodemailer = require('nodemailer');
require('dotenv').config();

// Cấu hình Transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS, // Nhớ dùng App Password 16 ký tự
  },
});

const formatCurrency = (amount) => {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
};

const formatDate = (date) => {
  return new Date(date).toLocaleDateString('vi-VN', { 
    day: '2-digit', month: '2-digit', year: 'numeric', 
    hour: '2-digit', minute: '2-digit' 
  });
};

const sendInvoiceEmail = async (order) => {
  try {
    const recipientEmail = order.customer.email;
    
    // Nếu không có email khách, gửi về admin để check
    const finalReceiver = recipientEmail || process.env.EMAIL_USER; 
    
    // Tạo các dòng sản phẩm trong bảng
    const productRows = order.products.map((item, index) => `
      <tr style="border-bottom: 1px solid #eee;">
        <td style="padding: 10px; text-align: center; color: #555;">${index + 1}</td>
        <td style="padding: 10px; color: #333; font-weight: 500;">
          ${item.name}
          <div style="font-size: 12px; color: #888;">Mã SP: ${item._id.toString().slice(-5)}</div>
        </td>
        <td style="padding: 10px; text-align: center; color: #555;">${item.quantity}</td>
        <td style="padding: 10px; text-align: right; color: #555;">${formatCurrency(item.price)}</td>
        <td style="padding: 10px; text-align: right; color: #333; font-weight: bold;">${formatCurrency(item.price * item.quantity)}</td>
      </tr>
    `).join('');

    // --- MẪU HÓA ĐƠN HTML (INVOICE TEMPLATE) ---
    const htmlContent = `
      <div style="background-color: #f4f4f4; padding: 40px 0; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
          
          <div style="background-color: #d0021b; padding: 30px; text-align: center; color: #ffffff;">
            <h1 style="margin: 0; font-size: 28px; letter-spacing: 1px;">CÁI LÒ NƯỚNG</h1>
            <p style="margin: 5px 0 0; font-size: 14px; opacity: 0.9;">HÓA ĐƠN XÁC NHẬN ĐƠN HÀNG</p>
          </div>

          <div style="padding: 30px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 30px; border-bottom: 2px solid #f4f4f4; padding-bottom: 20px;">
              <div style="width: 50%;">
                <h3 style="margin: 0 0 10px; color: #333;">Thông tin khách hàng</h3>
                <p style="margin: 3px 0; color: #555; font-size: 14px;">Họ tên: <strong>${order.customer.name}</strong></p>
                <p style="margin: 3px 0; color: #555; font-size: 14px;">SĐT: ${order.customer.phone}</p>
                <p style="margin: 3px 0; color: #555; font-size: 14px;">Email: ${order.customer.email || 'Không có'}</p>
                <p style="margin: 3px 0; color: #555; font-size: 14px;">Địa chỉ: ${order.customer.address}</p>
              </div>
              <div style="width: 50%; text-align: right;">
                <h3 style="margin: 0 0 10px; color: #333;">Đơn hàng #${order.orderCode || order._id.toString().slice(-5)}</h3>
                <p style="margin: 3px 0; color: #555; font-size: 14px;">Ngày đặt: ${formatDate(order.createdAt)}</p>
                <p style="margin: 3px 0; color: #555; font-size: 14px;">Thanh toán: <strong>${order.paymentMethod === 'banking' ? 'Chuyển khoản' : 'Tiền mặt'}</strong></p>
                
              </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
              <thead>
                <tr style="background-color: #f8f8f8; text-transform: uppercase; font-size: 12px; letter-spacing: 0.5px;">
                  <th style="padding: 12px; text-align: center; color: #888; border-bottom: 2px solid #eee;">STT</th>
                  <th style="padding: 12px; text-align: left; color: #888; border-bottom: 2px solid #eee;">Sản phẩm</th>
                  <th style="padding: 12px; text-align: center; color: #888; border-bottom: 2px solid #eee;">SL</th>
                  <th style="padding: 12px; text-align: right; color: #888; border-bottom: 2px solid #eee;">Đơn giá</th>
                  <th style="padding: 12px; text-align: right; color: #888; border-bottom: 2px solid #eee;">Thành tiền</th>
                </tr>
              </thead>
              <tbody>
                ${productRows}
              </tbody>
            </table>

            <div style="border-top: 2px solid #f4f4f4; padding-top: 15px;">
              <table style="width: 100%;">
                <tr>
                  <td style="text-align: right; padding: 5px; color: #555;">Tạm tính:</td>
                  <td style="text-align: right; padding: 5px; width: 120px; color: #333;">${formatCurrency(order.amounts.subtotal)}</td>
                </tr>
                <tr>
                  <td style="text-align: right; padding: 5px; color: #555;">Phí vận chuyển:</td>
                  <td style="text-align: right; padding: 5px; color: #333;">${formatCurrency(order.amounts.ship)}</td>
                </tr>
                <tr>
                  <td style="text-align: right; padding: 10px 5px; font-size: 18px; font-weight: bold; color: #d0021b;">TỔNG CỘNG:</td>
                  <td style="text-align: right; padding: 10px 5px; font-size: 18px; font-weight: bold; color: #d0021b;">${formatCurrency(order.amounts.total)}</td>
                </tr>
              </table>
            </div>

            ${order.paymentMethod === 'banking' ? `
              <div style="background-color: #fff4f4; border: 1px dashed #d0021b; padding: 15px; margin-top: 20px; border-radius: 6px;">
                <p style="margin: 0 0 5px; color: #d0021b; font-weight: bold;">THÔNG TIN CHUYỂN KHOẢN:</p>
                <p style="margin: 3px 0; font-size: 14px;">Ngân hàng: <strong>VIB</strong></p>
                <p style="margin: 3px 0; font-size: 14px;">Số tài khoản: <strong>003863231</strong></p>
                <p style="margin: 3px 0; font-size: 14px;">Chủ tài khoản: <strong>Cong ty TNHH Cai Lo Nuong</strong></p>
                <p style="margin: 3px 0; font-size: 14px;">Nội dung CK: <strong>${order.customer.phone}</strong></p>
              </div>
            ` : ''}
            
            <div style="text-align: center; margin-top: 40px; border-top: 1px solid #eee; padding-top: 20px; color: #888; font-size: 12px;">
              <p>Cảm ơn bạn đã lựa chọn Cái Lò Nướng!</p>
              <p>Mọi thắc mắc vui lòng liên hệ: 0342143812 hoặc website cailonuong.com</p>
            </div>

          </div>
        </div>
      </div>
    `;

    // Gửi mail
    await transporter.sendMail({
      from: `"Cái Lò Nướng Bakery" <${process.env.EMAIL_USER}>`,
      to: finalReceiver,
      subject: `[HÓA ĐƠN] Xác nhận đơn hàng #${order.orderCode || order._id}`,
      html: htmlContent,
    });

    console.log('✅ Đã gửi hóa đơn đến:', finalReceiver);

  } catch (error) {
    console.error('❌ Lỗi gửi mail:', error);
  }
};

module.exports = { sendInvoiceEmail };